﻿namespace Project_4
{
    partial class Form_man_modify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label1_1 = new System.Windows.Forms.Label();
            this.label1_2 = new System.Windows.Forms.Label();
            this.label1_3 = new System.Windows.Forms.Label();
            this.label1_4 = new System.Windows.Forms.Label();
            this.label1_5 = new System.Windows.Forms.Label();
            this.label1_6 = new System.Windows.Forms.Label();
            this.label1_7 = new System.Windows.Forms.Label();
            this.label1_8 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(152, 341);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 24);
            this.label5.TabIndex = 101;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(172, 215);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(99, 33);
            this.comboBox1.TabIndex = 83;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox8.Location = new System.Drawing.Point(1442, 275);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(152, 31);
            this.textBox8.TabIndex = 88;
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox5.Location = new System.Drawing.Point(1462, 155);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(238, 31);
            this.textBox5.TabIndex = 81;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox2.Location = new System.Drawing.Point(1483, 35);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(217, 31);
            this.textBox2.TabIndex = 76;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox7.Location = new System.Drawing.Point(1116, 275);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(155, 31);
            this.textBox7.TabIndex = 87;
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox6.Location = new System.Drawing.Point(1277, 215);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(317, 31);
            this.textBox6.TabIndex = 84;
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox4.Location = new System.Drawing.Point(1172, 155);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(187, 31);
            this.textBox4.TabIndex = 79;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox3.Location = new System.Drawing.Point(1132, 95);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(568, 31);
            this.textBox3.TabIndex = 77;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox1.Location = new System.Drawing.Point(1131, 35);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(140, 31);
            this.textBox1.TabIndex = 74;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(421, 280);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1, 24);
            this.panel9.TabIndex = 99;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(151, 220);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1, 24);
            this.panel8.TabIndex = 98;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(441, 160);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1, 24);
            this.panel7.TabIndex = 97;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(459, 40);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1, 24);
            this.panel6.TabIndex = 96;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(99, 280);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 24);
            this.panel5.TabIndex = 94;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(151, 160);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1, 24);
            this.panel3.TabIndex = 95;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(116, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1, 24);
            this.panel2.TabIndex = 100;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(115, 40);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1, 24);
            this.panel1.TabIndex = 93;
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button2.Location = new System.Drawing.Point(652, 349);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(70, 50);
            this.button2.TabIndex = 92;
            this.button2.Text = "완료";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            this.button2.MouseLeave += new System.EventHandler(this.button2_MouseLeave);
            this.button2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button2_MouseMove);
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button1.Location = new System.Drawing.Point(116, 340);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(25, 25);
            this.button1.TabIndex = 90;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(60, 340);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 24);
            this.label10.TabIndex = 91;
            this.label10.Text = "사진";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(365, 280);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 24);
            this.label9.TabIndex = 89;
            this.label9.Text = "PW";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(60, 280);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 24);
            this.label8.TabIndex = 86;
            this.label8.Text = "ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(365, 160);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 24);
            this.label7.TabIndex = 85;
            this.label7.Text = "이메일";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(60, 220);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 24);
            this.label6.TabIndex = 82;
            this.label6.Text = "계좌번호";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(60, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 24);
            this.label4.TabIndex = 80;
            this.label4.Text = "전화번호";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(60, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 24);
            this.label3.TabIndex = 78;
            this.label3.Text = "주소";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(365, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 24);
            this.label2.TabIndex = 75;
            this.label2.Text = "주민번호";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(60, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 24);
            this.label1.TabIndex = 73;
            this.label1.Text = "이름";
            // 
            // label1_1
            // 
            this.label1_1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label1_1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label1_1.Location = new System.Drawing.Point(127, 38);
            this.label1_1.Name = "label1_1";
            this.label1_1.Size = new System.Drawing.Size(210, 29);
            this.label1_1.TabIndex = 109;
            this.label1_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1_1.Click += new System.EventHandler(this.label1_1_Click);
            // 
            // label1_2
            // 
            this.label1_2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label1_2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label1_2.Location = new System.Drawing.Point(480, 38);
            this.label1_2.Name = "label1_2";
            this.label1_2.Size = new System.Drawing.Size(210, 29);
            this.label1_2.TabIndex = 110;
            this.label1_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1_2.Click += new System.EventHandler(this.label1_2_Click);
            // 
            // label1_3
            // 
            this.label1_3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label1_3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label1_3.Location = new System.Drawing.Point(127, 100);
            this.label1_3.Name = "label1_3";
            this.label1_3.Size = new System.Drawing.Size(562, 29);
            this.label1_3.TabIndex = 111;
            this.label1_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1_3.Click += new System.EventHandler(this.label1_3_Click);
            // 
            // label1_4
            // 
            this.label1_4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label1_4.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label1_4.Location = new System.Drawing.Point(172, 160);
            this.label1_4.Name = "label1_4";
            this.label1_4.Size = new System.Drawing.Size(187, 29);
            this.label1_4.TabIndex = 112;
            this.label1_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1_4.Click += new System.EventHandler(this.label1_4_Click);
            // 
            // label1_5
            // 
            this.label1_5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label1_5.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label1_5.Location = new System.Drawing.Point(466, 160);
            this.label1_5.Name = "label1_5";
            this.label1_5.Size = new System.Drawing.Size(210, 29);
            this.label1_5.TabIndex = 113;
            this.label1_5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1_5.Click += new System.EventHandler(this.label1_5_Click);
            // 
            // label1_6
            // 
            this.label1_6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label1_6.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label1_6.Location = new System.Drawing.Point(296, 219);
            this.label1_6.Name = "label1_6";
            this.label1_6.Size = new System.Drawing.Size(380, 29);
            this.label1_6.TabIndex = 114;
            this.label1_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1_6.Click += new System.EventHandler(this.label1_6_Click);
            // 
            // label1_7
            // 
            this.label1_7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label1_7.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label1_7.Location = new System.Drawing.Point(127, 279);
            this.label1_7.Name = "label1_7";
            this.label1_7.Size = new System.Drawing.Size(210, 29);
            this.label1_7.TabIndex = 115;
            this.label1_7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1_7.Click += new System.EventHandler(this.label1_7_Click);
            // 
            // label1_8
            // 
            this.label1_8.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label1_8.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label1_8.Location = new System.Drawing.Point(455, 279);
            this.label1_8.Name = "label1_8";
            this.label1_8.Size = new System.Drawing.Size(210, 29);
            this.label1_8.TabIndex = 116;
            this.label1_8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1_8.Click += new System.EventHandler(this.label1_8_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(127, 70);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(210, 1);
            this.panel4.TabIndex = 117;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.Location = new System.Drawing.Point(480, 70);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(210, 1);
            this.panel10.TabIndex = 118;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.Location = new System.Drawing.Point(131, 132);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(562, 1);
            this.panel11.TabIndex = 118;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Black;
            this.panel12.Location = new System.Drawing.Point(172, 192);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(187, 1);
            this.panel12.TabIndex = 119;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Black;
            this.panel13.Location = new System.Drawing.Point(466, 192);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(210, 1);
            this.panel13.TabIndex = 120;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Black;
            this.panel14.Location = new System.Drawing.Point(296, 251);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(380, 1);
            this.panel14.TabIndex = 121;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Black;
            this.panel15.Location = new System.Drawing.Point(127, 311);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(210, 1);
            this.panel15.TabIndex = 120;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.Black;
            this.panel16.Location = new System.Drawing.Point(455, 311);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(210, 1);
            this.panel16.TabIndex = 121;
            // 
            // Form_man_modify
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(734, 411);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label1_8);
            this.Controls.Add(this.label1_7);
            this.Controls.Add(this.label1_6);
            this.Controls.Add(this.label1_5);
            this.Controls.Add(this.label1_4);
            this.Controls.Add(this.label1_3);
            this.Controls.Add(this.label1_2);
            this.Controls.Add(this.label1_1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form_man_modify";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form_man_modify";
            this.Load += new System.EventHandler(this.Form_man_modify_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.ComboBox comboBox1;
        public System.Windows.Forms.TextBox textBox8;
        public System.Windows.Forms.TextBox textBox5;
        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.TextBox textBox7;
        public System.Windows.Forms.TextBox textBox6;
        public System.Windows.Forms.TextBox textBox4;
        public System.Windows.Forms.TextBox textBox3;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.Panel panel9;
        public System.Windows.Forms.Panel panel8;
        public System.Windows.Forms.Panel panel7;
        public System.Windows.Forms.Panel panel6;
        public System.Windows.Forms.Panel panel5;
        public System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label1_1;
        public System.Windows.Forms.Label label1_2;
        public System.Windows.Forms.Label label1_3;
        public System.Windows.Forms.Label label1_4;
        public System.Windows.Forms.Label label1_5;
        public System.Windows.Forms.Label label1_6;
        public System.Windows.Forms.Label label1_7;
        public System.Windows.Forms.Label label1_8;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
    }
}