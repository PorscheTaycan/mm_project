﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Project_4
{
    public partial class Form_pay : Form
    {
        static Random random = new Random();   // 랜덤 수 생성
        private outpatient outpatient;
                                               //Form_login.Form_main form_Main = new form_main(this);
        DataGridViewCheckBoxCell[] dataGridViewCheckBoxCellarray = new DataGridViewCheckBoxCell[100];

        public Form_pay(string[] rowdata)
        {

            InitializeComponent();

            // 현재 DataGridView에 있는 모든 행 삭제
            //dataGridView1.Rows.Clear();

            
            string medicalFilePath = "medical.txt";
            string PayFilePath = "PayData.txt"; // 환자 정보 파일 경로
            
            if(File.Exists(PayFilePath))
            {
                string[] medical_lines = File.ReadAllLines(medicalFilePath);


                foreach (string line in medical_lines)
                {
                    string str = "";

                    string[] Pays = line.ToString().Split('\t');

                    int RanNum = random.Next(1000, 200000);
                    int RanNum2 = (RanNum / 100) * 100;
                    str = string.Format("{0:#,###}", RanNum2);


                    
                    File.AppendAllText(PayFilePath, Pays[0] + "\t" + Pays[1] + "\t" + str + "\t" + DateTime.Now.ToString("yyyy-MM-dd") + "\t" + "X" + "\n");

                }
                //File.WriteAllText(PayFilePath, string.Empty);


                DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();

                try
                {

                    checkBoxColumn.HeaderText = "여부";


                    dataGridView1.Columns.Add(checkBoxColumn);
                    string[] pay_lines = File.ReadAllLines(PayFilePath);

                    for (int i = 0; i < pay_lines.Length; i++)
                    {
                        string[] Pays = pay_lines[i].Split('\t');
                        dataGridView1.Rows.Add(Pays[0], Pays[1], Pays[2], false);

                    }

                    dataGridView1.CurrentCellDirtyStateChanged += new EventHandler(delegate (Object o, EventArgs a)
                    {

                        for (int i = 0; i < dataGridView1.Rows.Count; i++)
                        {

                            if (i == dataGridView1.CurrentCell.RowIndex)
                            {
                                if (Convert.ToBoolean(dataGridView1.CurrentCell.Value))
                                {
                                    // 전체 파일을 읽어옵니다.
                                    string[] allLines = File.ReadAllLines(PayFilePath);

                                    // 현재 선택한 행의 X를 O로 변경합니다.
                                    string[] selectedRow = allLines[dataGridView1.CurrentCell.RowIndex].Split('\t');
                                    selectedRow[4] = "O";

                                    // 변경된 내용을 메모리 상에서 수정한 뒤 다시 파일에 씁니다.
                                    allLines[dataGridView1.CurrentCell.RowIndex] = string.Join("\t", selectedRow);

                                    // 전체 내용을 파일에 다시 씁니다.
                                    File.WriteAllLines(PayFilePath, allLines);
                                }
                                else
                                {
                                    // 전체 파일을 읽어옵니다.
                                    string[] allLines = File.ReadAllLines(PayFilePath);

                                    // 현재 선택한 행의 X를 O로 변경합니다.
                                    string[] selectedRow = allLines[dataGridView1.CurrentCell.RowIndex].Split('\t');
                                    selectedRow[4] = "X";

                                    // 변경된 내용을 메모리 상에서 수정한 뒤 다시 파일에 씁니다.
                                    allLines[dataGridView1.CurrentCell.RowIndex] = string.Join("\t", selectedRow);

                                    // 전체 내용을 파일에 다시 씁니다.
                                    File.WriteAllLines(PayFilePath, allLines);
                                }
                            }


                        }

                    });

                    string[] payline = File.ReadAllLines(PayFilePath);
                    for (int k = 0; k < payline.Length; k++)
                    {

                        string[] Pays_line = payline[k].Split('\t');
                        if (Pays_line[4] == "O")
                        {

                            dataGridView1.Rows[k].Cells[3].Value = true;
                        }
                        else
                        {
                            dataGridView1.Rows[k].Cells[3].Value = false;
                        }

                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show("예외가 발생했습니다: " + ex.Message);
                }
            }
            else
            {
                try
                {
                    // 새로운 메모장 파일 생성
                    using (StreamWriter writer = File.CreateText(PayFilePath))
                    {

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("예외가 발생했습니다: " + ex.Message);
                }

            }
            

        }
    }
}

