﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace Project_4
{
    public partial class outpatient : Form
    {
        private static int countClinic1 = 0; // 진료실1 카운트를 저장하는 정적 변수
        private static int countClinic2 = 0;
        private static int textBoxCount = 0;
        //time tick
        private Timer timer;
        public outpatient(string[] rowData)
        {
            InitializeComponent();
            dataGridView1.Rows.Add(rowData);//outpatient폼에 그리드뷰안에 폼1의 데이터 기입

        }
        private void outpatient_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = comboBox2.Items.Count - 1;
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = null;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow2 = dataGridView1.SelectedRows[0];
            string[] rowData = new string[selectedRow2.Cells.Count];
            for (int i = 0; i < selectedRow2.Cells.Count; i++)
            {
                rowData[i] = selectedRow2.Cells[i].Value.ToString();
            }

            NewTB(rowData);
            this.Close();



        }


        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        private System.Windows.Forms.TextBox FindTextBoxByButton(System.Windows.Forms.Button button)
        {
            Control textBoxControl = button.Parent;
            if (textBoxControl is System.Windows.Forms.TextBox)
            {
                return (System.Windows.Forms.TextBox)textBoxControl;
            }
            return null;
        }
        private bool MoveTextBox(System.Windows.Forms.TextBox textBox)
        {
            // 여기에 텍스트박스를 탭 페이지 2로 이동할 수 있는 조건을 추가합니다.
            return true; // 예시로 모든 텍스트박스를 이동할 수 있도록 합니다.
        }
        private void TabPage2(System.Windows.Forms.TextBox textBox)
        {
            Form_login.form_main.tabPage1.Controls.Remove(textBox);

            // 탭 페이지 2에서 마지막으로 생성된 컨트롤의 위치를 기준으로 여백을 추가하여 위치를 지정합니다.
            int lastControlBottom = 0;
            foreach (Control control in Form_login.form_main.tabPage2.Controls)
            {
                if (control.Bottom > lastControlBottom)
                {
                    lastControlBottom = control.Bottom;
                }
            }

            // 여백을 추가하여 새로운 텍스트 박스의 위치를 지정합니다.
            int newLocationY = lastControlBottom + 20;
            textBox.Location = new System.Drawing.Point(6, newLocationY);

            Form_login.form_main.tabPage2.Controls.Add(textBox);
        }
        private void Count(System.Windows.Forms.TextBox textBox)
        {
            string text = textBox.Text;

            // "진료1실"-Regex.Matches(찾을데이터유형,찾을데이터) 사용해 카운트
            countClinic1 -= Regex.Matches(text, "진료1실").Count;
            Form_login.form_main.label21.Text = "진료 1실 대기인원 : " + countClinic1.ToString();
            //진료2실
            countClinic2 -= Regex.Matches(text, "진료2실").Count;
            Form_login.form_main.label22.Text = "진료 2실 대기인원 : " + countClinic2.ToString();
            if (countClinic1 == 0 || countClinic2 == 0)
            {
                Form_login.form_main.label21.Text = "진료 1실 대기인원 : " + countClinic1.ToString();
                Form_login.form_main.label22.Text = "진료 2실 대기인원 : " + countClinic2.ToString();
            }
        }
        private void Timer_Tick(object sender, EventArgs e)
        {


            Alarm alarm = new Alarm();
            alarm.Text = null;
            timer.Stop();

            Check();
        }
        private void NewButton_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Button clickedButton = (System.Windows.Forms.Button)sender;

            if (clickedButton.Text == "진료대기")
            {
                System.Windows.Forms.TextBox targetTextBox = FindTextBoxByButton(clickedButton);
                Count(targetTextBox);
                clickedButton.Text = "진료중";

                Random random = new Random();
                timer = new Timer();
                timer.Interval = random.Next(15000, 20000);
                timer.Tick += Timer_Tick;
                timer.Start();

                // 진료 중 버튼이 클릭되면, 진료 대기 버튼을 다른 텍스트박스에서 비활성화합니다.
                DisableWaitingButtons(targetTextBox);
            }
            else if (clickedButton.Text == "진료중")
            {
                clickedButton.Text = "진료완료";
                System.Windows.Forms.TextBox targetTextBox = FindTextBoxByButton(clickedButton);
                System.Windows.Forms.Button button = (System.Windows.Forms.Button)sender;
                // 텍스트박스가 존재하고, 탭 페이지를 변경할 수 있는 조건을 확인
                if (targetTextBox != null && MoveTextBox(targetTextBox))
                {
                    // 탭 페이지 2로 텍스트박스 이동
                    TabPage2(targetTextBox);
                }
                textBoxCount--;

                // 진료 완료 시 다른 텍스트박스에서 진료 대기 버튼을 다시 활성화합니다.
                EnableWaitingButtons(targetTextBox);

  
            }
        }
        private void DisableWaitingButtons(System.Windows.Forms.TextBox currentTextBox)
        {
            // 현재 진료 중인 텍스트박스의 진료실 번호를 가져옵니다.
            string currentClinic = currentTextBox.Text.Split('/')[1];

            // 모든 텍스트박스를 순회하며 진료 대기 버튼을 처리합니다.
            foreach (Control control in Form_login.form_main.tabPage1.Controls)
            {
                if (control is System.Windows.Forms.TextBox)
                {
                    System.Windows.Forms.TextBox textBox = (System.Windows.Forms.TextBox)control;
                    System.Windows.Forms.Button button = (System.Windows.Forms.Button)textBox.Controls[0]; // 텍스트박스 내부에 있는 버튼을 가져옵니다.
                    string clinic = textBox.Text.Split('/')[1]; // 현재 텍스트박스의 진료실 번호를 가져옵니다.

                    // 현재 진료실과 같은 진료실의 버튼만 잠깁니다.
                    if (clinic == currentClinic && button.Text == "진료대기")
                    {
                        button.Enabled = false;
                    }
                }
            }
        }
        private void EnableWaitingButtons(System.Windows.Forms.TextBox currentTextBox)
        {
            // 모든 텍스트박스를 순회하며 현재 진료 중인 텍스트박스와 동일한 진료실을 가지고 있는 진료 대기 버튼을 활성화합니다.
            foreach (Control control in Form_login.form_main.tabPage1.Controls)
            {
                if (control is System.Windows.Forms.TextBox && control != currentTextBox)
                {
                    System.Windows.Forms.TextBox textBox = (System.Windows.Forms.TextBox)control;
                    System.Windows.Forms.Button button = (System.Windows.Forms.Button)textBox.Controls[0]; // 텍스트박스 내부에 있는 버튼을 가져옵니다.
                    if (textBox.Text.Contains(currentTextBox.Text.Split('/')[1]) && button.Text == "진료대기")
                    {
                        button.Enabled = true;
                    }
                }
            }
        }
        private void NewTB(string[] rowData)
        {
            // 텍스트 박스 생성
            System.Windows.Forms.TextBox newTextBox = new System.Windows.Forms.TextBox();
            newTextBox.Multiline = true;
            newTextBox.ReadOnly = true;
            newTextBox.Name = "newTextBox";
            newTextBox.Size = new System.Drawing.Size(270, 100); // 크기 지정
            newTextBox.Location = new System.Drawing.Point(6, 20 + textBoxCount * 120); // 생성 위치 지정
            newTextBox.Font = new Font("G마켓 산스 TTF Light", 12, FontStyle.Bold);  // 폰트 지정

            Form_login.form_main.tabPage1.Controls.Add(newTextBox); // 탭 페이지에 텍스트 박스 추가

            // 버튼 생성
            System.Windows.Forms.Button newButton = new System.Windows.Forms.Button();
            newButton.Text = "진료대기";
            newButton.Size = new Size(70, 30);
            newButton.Font = new Font("G마켓 산스 TTF Light", 9, FontStyle.Bold);
            newButton.Location = new Point(newTextBox.Width - newButton.Width - 5, 0);
            newButton.Click += new EventHandler(NewButton_Click);

            newTextBox.Controls.Add(newButton);//텍스트박스에 버튼추가

            // 텍스트 설정
            newTextBox.Text = comboBox1.Text + "/" + comboBox2.Text + Environment.NewLine + Environment.NewLine;
            for (int i = 0; i <= 2; i++)
            {
                newTextBox.Text += rowData[i];

                if (i != 2)
                {
                    newTextBox.Text += "/";

                }

            }

            //이윤서
            string medicalFilePath = "medical.txt"; // 접수 정보 파일 경로
            File.AppendAllText(medicalFilePath, rowData[0] + "\t" + rowData[2]+ Environment.NewLine);  // 접수 환자 이름과 생년월일 가져옴.


            // 접수 시간 추가
            string formattedDateTime = DateTime.Now.ToString("yy.MM.dd-HH:mm");
            newTextBox.Text += Environment.NewLine + "접수시간 : " + formattedDateTime;

            // 생성된 텍스트 박스 개수 증가
            textBoxCount++;

            // 대기실 인원 카운트
            WaitCount();
        }
        private void WaitCount()
        {
            if (comboBox1.Text == "진료1실")
            {
                countClinic1++;
                Form_login.form_main.label21.Text = "진료 1실 대기인원 : " + countClinic1.ToString();
            }
            else if (comboBox1.Text == "진료2실")
            {
                countClinic2++;
                Form_login.form_main.label22.Text = "진료 2실 대기인원 : " + countClinic2.ToString();
            }
        }
        private void Check()
        {
            Alarm alarm = new Alarm();
            System.Windows.Forms.TextBox newTextBox = Form_login.form_main.Controls.Find("newTextBox", true).FirstOrDefault() as System.Windows.Forms.TextBox;
            //MessageBox.Show(newTextBox.Text.Substring(0, 4));
            alarm.label1.Text = newTextBox.Text.Substring(0, 4) + "\n" + "진료 완료";
            alarm.ShowDialog();
            //DialogResult result = MessageBox.Show("진료실 진료완료", "알림", MessageBoxButtons.OK);
            //timer.Stop();
            ClickButton();
        }
        private void ClickButton()
        {
            // 폼 내의 모든 컨트롤을 탐색하여 동적으로 생성된 텍스트박스의 버튼을 찾음
            foreach (Control control in Form_login.form_main.tabPage1.Controls)
            {
                if (control is System.Windows.Forms.TextBox)
                {
                    System.Windows.Forms.TextBox textBox = (System.Windows.Forms.TextBox)control;
                    // 텍스트박스 내부의 버튼을 찾음
                    foreach (Control innerControl in textBox.Controls)
                    {
                        if (innerControl is System.Windows.Forms.Button)
                        {
                            System.Windows.Forms.Button button = (System.Windows.Forms.Button)innerControl;

                            //버튼의 텍스트가 진료중인지 확인하는 조건문
                            if (button.Text.Contains("진료중"))
                            {
                                // 찾은 버튼을 클릭하도록 함
                                button.PerformClick();
                                return; // 버튼을 찾고 클릭했으므로 더 이상의 탐색은 종료
                            }
                        }
                    }
                }
            }
        }

    }
}
