﻿namespace Project_4
{
    partial class Form_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1_2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.panel1_3 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel1_1 = new System.Windows.Forms.Panel();
            this.button13 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel3_2 = new System.Windows.Forms.Panel();
            this.label3_2_1 = new System.Windows.Forms.Label();
            this.dataGridView3_2_1 = new System.Windows.Forms.DataGridView();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.button3_2_1 = new System.Windows.Forms.Button();
            this.textBox3_2_1 = new System.Windows.Forms.TextBox();
            this.button3_3_3 = new System.Windows.Forms.Button();
            this.panel3_3 = new System.Windows.Forms.Panel();
            this.label3_3_2 = new System.Windows.Forms.Label();
            this.textBox3_3_1 = new System.Windows.Forms.TextBox();
            this.button3_2_2 = new System.Windows.Forms.Button();
            this.button3_3_2 = new System.Windows.Forms.Button();
            this.button3_3_1 = new System.Windows.Forms.Button();
            this.dataGridView3_3_1 = new System.Windows.Forms.DataGridView();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.label3_3_1 = new System.Windows.Forms.Label();
            this.panel3_1 = new System.Windows.Forms.Panel();
            this.label3_1_4 = new System.Windows.Forms.Label();
            this.label3_1_3 = new System.Windows.Forms.Label();
            this.label3_1_2 = new System.Windows.Forms.Label();
            this.button3_1_2 = new System.Windows.Forms.Button();
            this.textBox3_1_2 = new System.Windows.Forms.TextBox();
            this.label3_1_1 = new System.Windows.Forms.Label();
            this.button3_1_1 = new System.Windows.Forms.Button();
            this.textBox3_1_1 = new System.Windows.Forms.TextBox();
            this.button3_1_3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button19 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.Daycontainer = new System.Windows.Forms.FlowLayoutPanel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.panel56 = new System.Windows.Forms.Panel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel52 = new System.Windows.Forms.Panel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel49 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel4_1 = new System.Windows.Forms.Panel();
            this.button4_1_1 = new System.Windows.Forms.Button();
            this.textBox4_1_7 = new System.Windows.Forms.TextBox();
            this.textBox4_1_6 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox4_1_5 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.panel4_1_1 = new System.Windows.Forms.Panel();
            this.textBox4_1_4 = new System.Windows.Forms.TextBox();
            this.textBox4_1_3 = new System.Windows.Forms.TextBox();
            this.textBox4_1_2 = new System.Windows.Forms.TextBox();
            this.textBox4_1_1 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView4_2 = new System.Windows.Forms.DataGridView();
            this.Column32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel4_2 = new System.Windows.Forms.Panel();
            this.button4_2 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button4_3 = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.dataGridView4_4 = new System.Windows.Forms.DataGridView();
            this.Column33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column36 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button4_1 = new System.Windows.Forms.Button();
            this.dataGridView4_1 = new System.Windows.Forms.DataGridView();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button12 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.button5 = new System.Windows.Forms.Button();
            this.main_textBox1 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel1_2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel1_3.SuspendLayout();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.panel1_1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel3_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3_2_1)).BeginInit();
            this.panel3_3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3_3_1)).BeginInit();
            this.panel3_1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.panel13.SuspendLayout();
            this.Daycontainer.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel4_1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_2)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.panel4_2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_4)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_1)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.panel1_2);
            this.panel1.Controls.Add(this.panel1_3);
            this.panel1.Controls.Add(this.panel1_1);
            this.panel1.Location = new System.Drawing.Point(325, 65);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1245, 780);
            this.panel1.TabIndex = 0;
            // 
            // panel1_2
            // 
            this.panel1_2.BackColor = System.Drawing.Color.White;
            this.panel1_2.Controls.Add(this.panel6);
            this.panel1_2.Controls.Add(this.textBox7);
            this.panel1_2.Controls.Add(this.textBox6);
            this.panel1_2.Controls.Add(this.textBox5);
            this.panel1_2.Controls.Add(this.textBox4);
            this.panel1_2.Location = new System.Drawing.Point(709, 0);
            this.panel1_2.Name = "panel1_2";
            this.panel1_2.Size = new System.Drawing.Size(539, 286);
            this.panel1_2.TabIndex = 1;
            this.panel1_2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel1_2_MouseClick);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.button6);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.button15);
            this.panel6.Controls.Add(this.button9);
            this.panel6.Controls.Add(this.label12);
            this.panel6.Controls.Add(this.button14);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.button10);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Location = new System.Drawing.Point(16, 14);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(502, 251);
            this.panel6.TabIndex = 17;
            this.panel6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel6_MouseClick);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(362, 198);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(100, 35);
            this.button6.TabIndex = 7;
            this.button6.TabStop = false;
            this.button6.Text = "신규등록";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(208, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = "010122";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(64, 200);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(222, 25);
            this.label10.TabIndex = 8;
            this.label10.Text = "입력한 내용을 확인해주세요.";
            this.label10.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(36, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 25);
            this.label6.TabIndex = 1;
            this.label6.Text = "생년월일";
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.DimGray;
            this.button15.BackgroundImage = global::Project_4.Properties.Resources._____;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.ForeColor = System.Drawing.Color.Transparent;
            this.button15.Location = new System.Drawing.Point(209, 190);
            this.button15.Margin = new System.Windows.Forms.Padding(0);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(192, 1);
            this.button15.TabIndex = 21;
            this.button15.TabStop = false;
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.DimGray;
            this.button9.BackgroundImage = global::Project_4.Properties.Resources._____;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.Color.DimGray;
            this.button9.Location = new System.Drawing.Point(207, 44);
            this.button9.Margin = new System.Windows.Forms.Padding(0);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(192, 1);
            this.button9.TabIndex = 18;
            this.button9.TabStop = false;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(208, 161);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 25);
            this.label12.TabIndex = 12;
            this.label12.Text = "대전시 서구";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.DimGray;
            this.button14.BackgroundImage = global::Project_4.Properties.Resources._____;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.ForeColor = System.Drawing.Color.Transparent;
            this.button14.Location = new System.Drawing.Point(210, 148);
            this.button14.Margin = new System.Windows.Forms.Padding(0);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(192, 1);
            this.button14.TabIndex = 20;
            this.button14.TabStop = false;
            this.button14.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Location = new System.Drawing.Point(208, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "이윤서";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.DimGray;
            this.button10.BackgroundImage = global::Project_4.Properties.Resources._____;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.ForeColor = System.Drawing.Color.Transparent;
            this.button10.Location = new System.Drawing.Point(209, 98);
            this.button10.Margin = new System.Windows.Forms.Padding(0);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(192, 1);
            this.button10.TabIndex = 19;
            this.button10.TabStop = false;
            this.button10.UseVisualStyleBackColor = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(208, 114);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(144, 25);
            this.label11.TabIndex = 11;
            this.label11.Text = "01012345678";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(36, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 25);
            this.label5.TabIndex = 0;
            this.label5.Text = "이름";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(36, 159);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 25);
            this.label8.TabIndex = 7;
            this.label8.Text = "주소";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(36, 118);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 25);
            this.label7.TabIndex = 2;
            this.label7.Text = "전화번호";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox7.Location = new System.Drawing.Point(1398, 204);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(200, 29);
            this.textBox7.TabIndex = 6;
            this.textBox7.Click += new System.EventHandler(this.textBox7_Click);
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            this.textBox7.Enter += new System.EventHandler(this.textBox7_Enter);
            this.textBox7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox7_KeyDown);
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox6.Location = new System.Drawing.Point(1427, 150);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(200, 29);
            this.textBox6.TabIndex = 5;
            this.textBox6.Click += new System.EventHandler(this.textBox6_Click);
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            this.textBox6.Enter += new System.EventHandler(this.textBox6_Enter);
            this.textBox6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox6_KeyDown);
            this.textBox6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox6_KeyPress);
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox5.Location = new System.Drawing.Point(614, 95);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(200, 29);
            this.textBox5.TabIndex = 4;
            this.textBox5.Click += new System.EventHandler(this.textBox5_Click);
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            this.textBox5.Enter += new System.EventHandler(this.textBox5_Enter);
            this.textBox5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox5_KeyDown);
            this.textBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox4.Location = new System.Drawing.Point(621, 44);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(200, 29);
            this.textBox4.TabIndex = 3;
            this.textBox4.Click += new System.EventHandler(this.textBox4_Click);
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            this.textBox4.Enter += new System.EventHandler(this.textBox4_Enter);
            this.textBox4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox4_KeyDown);
            // 
            // panel1_3
            // 
            this.panel1_3.BackColor = System.Drawing.Color.White;
            this.panel1_3.Controls.Add(this.panel11);
            this.panel1_3.Location = new System.Drawing.Point(709, 285);
            this.panel1_3.Name = "panel1_3";
            this.panel1_3.Size = new System.Drawing.Size(539, 495);
            this.panel1_3.TabIndex = 0;
            this.panel1_3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel1_3_MouseClick);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel11.Controls.Add(this.chart1);
            this.panel11.Location = new System.Drawing.Point(16, 21);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(503, 451);
            this.panel11.TabIndex = 0;
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            chartArea2.Name = "ChartArea2";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.ChartAreas.Add(chartArea2);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(0, 2);
            this.chart1.Name = "chart1";
            this.chart1.Size = new System.Drawing.Size(496, 442);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            this.chart1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.chart1_MouseClick);
            // 
            // panel1_1
            // 
            this.panel1_1.BackColor = System.Drawing.Color.White;
            this.panel1_1.Controls.Add(this.button13);
            this.panel1_1.Controls.Add(this.textBox1);
            this.panel1_1.Location = new System.Drawing.Point(-2, 0);
            this.panel1_1.Name = "panel1_1";
            this.panel1_1.Size = new System.Drawing.Size(712, 780);
            this.panel1_1.TabIndex = 0;
            this.panel1_1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel1_1_MouseClick);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(594, 722);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(100, 35);
            this.button13.TabIndex = 16;
            this.button13.Text = "수납";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 13);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(685, 746);
            this.textBox1.TabIndex = 3;
            this.textBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseClick);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(584, 613);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(100, 35);
            this.button8.TabIndex = 15;
            this.button8.TabStop = false;
            this.button8.Text = "접수";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click_2);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.panel3_2);
            this.panel3.Controls.Add(this.panel3_3);
            this.panel3.Controls.Add(this.panel3_1);
            this.panel3.Location = new System.Drawing.Point(325, 65);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1245, 780);
            this.panel3.TabIndex = 5;
            this.panel3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseClick);
            // 
            // panel3_2
            // 
            this.panel3_2.BackColor = System.Drawing.Color.White;
            this.panel3_2.Controls.Add(this.label3_2_1);
            this.panel3_2.Controls.Add(this.dataGridView3_2_1);
            this.panel3_2.Controls.Add(this.button3_2_1);
            this.panel3_2.Controls.Add(this.textBox3_2_1);
            this.panel3_2.Controls.Add(this.button3_3_3);
            this.panel3_2.Location = new System.Drawing.Point(1, 267);
            this.panel3_2.Name = "panel3_2";
            this.panel3_2.Size = new System.Drawing.Size(1243, 513);
            this.panel3_2.TabIndex = 1;
            this.panel3_2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel3_2_MouseClick);
            // 
            // label3_2_1
            // 
            this.label3_2_1.AutoSize = true;
            this.label3_2_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3_2_1.ForeColor = System.Drawing.Color.Red;
            this.label3_2_1.Location = new System.Drawing.Point(1012, 276);
            this.label3_2_1.Name = "label3_2_1";
            this.label3_2_1.Size = new System.Drawing.Size(0, 25);
            this.label3_2_1.TabIndex = 10;
            // 
            // dataGridView3_2_1
            // 
            this.dataGridView3_2_1.AllowUserToAddRows = false;
            this.dataGridView3_2_1.AllowUserToDeleteRows = false;
            this.dataGridView3_2_1.AllowUserToResizeColumns = false;
            this.dataGridView3_2_1.AllowUserToResizeRows = false;
            this.dataGridView3_2_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3_2_1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14});
            this.dataGridView3_2_1.Location = new System.Drawing.Point(21, 20);
            this.dataGridView3_2_1.Name = "dataGridView3_2_1";
            this.dataGridView3_2_1.RowHeadersVisible = false;
            this.dataGridView3_2_1.RowTemplate.Height = 23;
            this.dataGridView3_2_1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3_2_1.Size = new System.Drawing.Size(886, 475);
            this.dataGridView3_2_1.TabIndex = 6;
            this.dataGridView3_2_1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_2_1_CellContentClick);
            this.dataGridView3_2_1.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView3_2_1_ColumnHeaderMouseClick);
            // 
            // Column11
            // 
            this.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column11.HeaderText = "제품코드";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column12.HeaderText = "제품명";
            this.Column12.Name = "Column12";
            // 
            // Column13
            // 
            this.Column13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column13.HeaderText = "재고";
            this.Column13.Name = "Column13";
            // 
            // Column14
            // 
            this.Column14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column14.HeaderText = "선택";
            this.Column14.Name = "Column14";
            this.Column14.Width = 50;
            // 
            // button3_2_1
            // 
            this.button3_2_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3_2_1.Location = new System.Drawing.Point(1002, 368);
            this.button3_2_1.Name = "button3_2_1";
            this.button3_2_1.Size = new System.Drawing.Size(80, 50);
            this.button3_2_1.TabIndex = 1;
            this.button3_2_1.Text = "사용";
            this.button3_2_1.UseVisualStyleBackColor = true;
            this.button3_2_1.Click += new System.EventHandler(this.button3_2_1_Click);
            // 
            // textBox3_2_1
            // 
            this.textBox3_2_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox3_2_1.Location = new System.Drawing.Point(1008, 319);
            this.textBox3_2_1.Name = "textBox3_2_1";
            this.textBox3_2_1.Size = new System.Drawing.Size(153, 29);
            this.textBox3_2_1.TabIndex = 0;
            this.textBox3_2_1.Text = "수량";
            this.textBox3_2_1.Visible = false;
            this.textBox3_2_1.Click += new System.EventHandler(this.textBox3_2_1_Click);
            // 
            // button3_3_3
            // 
            this.button3_3_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3_3_3.Location = new System.Drawing.Point(1157, 39);
            this.button3_3_3.Name = "button3_3_3";
            this.button3_3_3.Size = new System.Drawing.Size(80, 50);
            this.button3_3_3.TabIndex = 3;
            this.button3_3_3.Text = "결재";
            this.button3_3_3.UseVisualStyleBackColor = true;
            this.button3_3_3.Click += new System.EventHandler(this.button3_3_3_Click);
            // 
            // panel3_3
            // 
            this.panel3_3.BackColor = System.Drawing.Color.White;
            this.panel3_3.Controls.Add(this.label3_3_2);
            this.panel3_3.Controls.Add(this.textBox3_3_1);
            this.panel3_3.Controls.Add(this.button3_2_2);
            this.panel3_3.Controls.Add(this.button3_3_2);
            this.panel3_3.Controls.Add(this.button3_3_1);
            this.panel3_3.Controls.Add(this.dataGridView3_3_1);
            this.panel3_3.Controls.Add(this.label3_3_1);
            this.panel3_3.Location = new System.Drawing.Point(325, 1);
            this.panel3_3.Name = "panel3_3";
            this.panel3_3.Size = new System.Drawing.Size(919, 278);
            this.panel3_3.TabIndex = 1;
            this.panel3_3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel3_3_MouseClick);
            // 
            // label3_3_2
            // 
            this.label3_3_2.AutoSize = true;
            this.label3_3_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3_3_2.ForeColor = System.Drawing.Color.Red;
            this.label3_3_2.Location = new System.Drawing.Point(630, 181);
            this.label3_3_2.Name = "label3_3_2";
            this.label3_3_2.Size = new System.Drawing.Size(0, 25);
            this.label3_3_2.TabIndex = 11;
            // 
            // textBox3_3_1
            // 
            this.textBox3_3_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox3_3_1.Location = new System.Drawing.Point(667, 220);
            this.textBox3_3_1.Name = "textBox3_3_1";
            this.textBox3_3_1.Size = new System.Drawing.Size(80, 29);
            this.textBox3_3_1.TabIndex = 0;
            this.textBox3_3_1.Visible = false;
            this.textBox3_3_1.Click += new System.EventHandler(this.textBox3_3_1_Click);
            // 
            // button3_2_2
            // 
            this.button3_2_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3_2_2.Location = new System.Drawing.Point(834, 207);
            this.button3_2_2.Name = "button3_2_2";
            this.button3_2_2.Size = new System.Drawing.Size(80, 50);
            this.button3_2_2.TabIndex = 2;
            this.button3_2_2.Text = "주문";
            this.button3_2_2.UseVisualStyleBackColor = true;
            this.button3_2_2.Click += new System.EventHandler(this.button3_2_2_Click);
            this.button3_2_2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.button3_2_2_KeyDown);
            // 
            // button3_3_2
            // 
            this.button3_3_2.BackgroundImage = global::Project_4.Properties.Resources.plus;
            this.button3_3_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3_3_2.Location = new System.Drawing.Point(752, 219);
            this.button3_3_2.Name = "button3_3_2";
            this.button3_3_2.Size = new System.Drawing.Size(30, 30);
            this.button3_3_2.TabIndex = 2;
            this.button3_3_2.UseVisualStyleBackColor = true;
            this.button3_3_2.Visible = false;
            this.button3_3_2.Click += new System.EventHandler(this.button3_3_2_Click);
            // 
            // button3_3_1
            // 
            this.button3_3_1.BackgroundImage = global::Project_4.Properties.Resources.minus;
            this.button3_3_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3_3_1.Location = new System.Drawing.Point(634, 220);
            this.button3_3_1.Name = "button3_3_1";
            this.button3_3_1.Size = new System.Drawing.Size(30, 30);
            this.button3_3_1.TabIndex = 1;
            this.button3_3_1.UseVisualStyleBackColor = true;
            this.button3_3_1.Visible = false;
            this.button3_3_1.Click += new System.EventHandler(this.button3_3_1_Click);
            // 
            // dataGridView3_3_1
            // 
            this.dataGridView3_3_1.AllowUserToAddRows = false;
            this.dataGridView3_3_1.AllowUserToDeleteRows = false;
            this.dataGridView3_3_1.AllowUserToResizeColumns = false;
            this.dataGridView3_3_1.AllowUserToResizeRows = false;
            this.dataGridView3_3_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3_3_1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column15,
            this.Column16,
            this.Column17,
            this.Column18});
            this.dataGridView3_3_1.Location = new System.Drawing.Point(21, 52);
            this.dataGridView3_3_1.Name = "dataGridView3_3_1";
            this.dataGridView3_3_1.RowHeadersVisible = false;
            this.dataGridView3_3_1.RowTemplate.Height = 23;
            this.dataGridView3_3_1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3_3_1.Size = new System.Drawing.Size(562, 196);
            this.dataGridView3_3_1.TabIndex = 7;
            this.dataGridView3_3_1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_3_1_CellContentClick);
            this.dataGridView3_3_1.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView3_3_1_ColumnHeaderMouseClick);
            // 
            // Column15
            // 
            this.Column15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column15.HeaderText = "제품명";
            this.Column15.Name = "Column15";
            // 
            // Column16
            // 
            this.Column16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column16.HeaderText = "수량";
            this.Column16.Name = "Column16";
            // 
            // Column17
            // 
            this.Column17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column17.HeaderText = "삭제";
            this.Column17.Name = "Column17";
            this.Column17.Width = 50;
            // 
            // Column18
            // 
            this.Column18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column18.HeaderText = "선택";
            this.Column18.Name = "Column18";
            this.Column18.Width = 50;
            // 
            // label3_3_1
            // 
            this.label3_3_1.AutoSize = true;
            this.label3_3_1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_3_1.Location = new System.Drawing.Point(20, 16);
            this.label3_3_1.Name = "label3_3_1";
            this.label3_3_1.Size = new System.Drawing.Size(90, 24);
            this.label3_3_1.TabIndex = 7;
            this.label3_3_1.Text = "장바구니";
            // 
            // panel3_1
            // 
            this.panel3_1.BackColor = System.Drawing.Color.White;
            this.panel3_1.Controls.Add(this.label3_1_4);
            this.panel3_1.Controls.Add(this.label3_1_3);
            this.panel3_1.Controls.Add(this.label3_1_2);
            this.panel3_1.Controls.Add(this.button3_1_2);
            this.panel3_1.Controls.Add(this.textBox3_1_2);
            this.panel3_1.Controls.Add(this.label3_1_1);
            this.panel3_1.Controls.Add(this.button3_1_1);
            this.panel3_1.Controls.Add(this.textBox3_1_1);
            this.panel3_1.Controls.Add(this.button3_1_3);
            this.panel3_1.Location = new System.Drawing.Point(1, 1);
            this.panel3_1.Name = "panel3_1";
            this.panel3_1.Size = new System.Drawing.Size(333, 274);
            this.panel3_1.TabIndex = 0;
            this.panel3_1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel3_1_MouseClick);
            // 
            // label3_1_4
            // 
            this.label3_1_4.AutoSize = true;
            this.label3_1_4.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_1_4.Location = new System.Drawing.Point(11, 124);
            this.label3_1_4.Name = "label3_1_4";
            this.label3_1_4.Size = new System.Drawing.Size(50, 24);
            this.label3_1_4.TabIndex = 8;
            this.label3_1_4.Text = "이름";
            // 
            // label3_1_3
            // 
            this.label3_1_3.AutoSize = true;
            this.label3_1_3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_1_3.Location = new System.Drawing.Point(11, 47);
            this.label3_1_3.Name = "label3_1_3";
            this.label3_1_3.Size = new System.Drawing.Size(50, 24);
            this.label3_1_3.TabIndex = 7;
            this.label3_1_3.Text = "코드";
            // 
            // label3_1_2
            // 
            this.label3_1_2.AutoSize = true;
            this.label3_1_2.ForeColor = System.Drawing.Color.Red;
            this.label3_1_2.Location = new System.Drawing.Point(24, 223);
            this.label3_1_2.Name = "label3_1_2";
            this.label3_1_2.Size = new System.Drawing.Size(0, 25);
            this.label3_1_2.TabIndex = 6;
            // 
            // button3_1_2
            // 
            this.button3_1_2.Location = new System.Drawing.Point(276, 158);
            this.button3_1_2.Name = "button3_1_2";
            this.button3_1_2.Size = new System.Drawing.Size(30, 30);
            this.button3_1_2.TabIndex = 3;
            this.button3_1_2.UseVisualStyleBackColor = true;
            this.button3_1_2.Click += new System.EventHandler(this.button3_1_2_Click);
            // 
            // textBox3_1_2
            // 
            this.textBox3_1_2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3_1_2.Location = new System.Drawing.Point(15, 158);
            this.textBox3_1_2.Name = "textBox3_1_2";
            this.textBox3_1_2.Size = new System.Drawing.Size(233, 29);
            this.textBox3_1_2.TabIndex = 2;
            this.textBox3_1_2.Click += new System.EventHandler(this.textBox3_1_2_Click);
            this.textBox3_1_2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox3_1_2_KeyDown);
            // 
            // label3_1_1
            // 
            this.label3_1_1.AutoSize = true;
            this.label3_1_1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_1_1.Location = new System.Drawing.Point(114, 7);
            this.label3_1_1.Name = "label3_1_1";
            this.label3_1_1.Size = new System.Drawing.Size(96, 24);
            this.label3_1_1.TabIndex = 3;
            this.label3_1_1.Text = "제품 검색";
            // 
            // button3_1_1
            // 
            this.button3_1_1.Location = new System.Drawing.Point(276, 73);
            this.button3_1_1.Name = "button3_1_1";
            this.button3_1_1.Size = new System.Drawing.Size(30, 30);
            this.button3_1_1.TabIndex = 1;
            this.button3_1_1.UseVisualStyleBackColor = true;
            this.button3_1_1.Click += new System.EventHandler(this.button3_1_1_Click);
            // 
            // textBox3_1_1
            // 
            this.textBox3_1_1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3_1_1.Location = new System.Drawing.Point(15, 74);
            this.textBox3_1_1.Name = "textBox3_1_1";
            this.textBox3_1_1.Size = new System.Drawing.Size(233, 29);
            this.textBox3_1_1.TabIndex = 0;
            this.textBox3_1_1.Click += new System.EventHandler(this.textBox3_1_1_Click);
            this.textBox3_1_1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox3_1_1_KeyDown);
            // 
            // button3_1_3
            // 
            this.button3_1_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3_1_3.Location = new System.Drawing.Point(226, 198);
            this.button3_1_3.Name = "button3_1_3";
            this.button3_1_3.Size = new System.Drawing.Size(80, 50);
            this.button3_1_3.TabIndex = 4;
            this.button3_1_3.Text = "등록";
            this.button3_1_3.UseVisualStyleBackColor = true;
            this.button3_1_3.Click += new System.EventHandler(this.button3_1_3_Click);
            this.button3_1_3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.button3_1_3_KeyDown);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 10F);
            this.button2.Location = new System.Drawing.Point(88, 69);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(65, 40);
            this.button2.TabIndex = 2;
            this.button2.Text = "근태";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Default;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 10F);
            this.button3.Location = new System.Drawing.Point(159, 69);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(65, 40);
            this.button3.TabIndex = 3;
            this.button3.Text = "재고";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Default;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 10F);
            this.button4.Location = new System.Drawing.Point(230, 68);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(83, 43);
            this.button4.TabIndex = 4;
            this.button4.Text = "관리자";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.panel14);
            this.panel2.Controls.Add(this.panel13);
            this.panel2.Controls.Add(this.panel12);
            this.panel2.Location = new System.Drawing.Point(324, 65);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1249, 780);
            this.panel2.TabIndex = 0;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.White;
            this.panel14.Controls.Add(this.button11);
            this.panel14.Controls.Add(this.dataGridView6);
            this.panel14.Controls.Add(this.button19);
            this.panel14.Controls.Add(this.button7);
            this.panel14.Location = new System.Drawing.Point(624, 0);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(624, 343);
            this.panel14.TabIndex = 5;
            this.panel14.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel14_MouseClick);
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.button11.Location = new System.Drawing.Point(454, 118);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(150, 80);
            this.button11.TabIndex = 6;
            this.button11.Text = "퇴근";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // dataGridView6
            // 
            this.dataGridView6.AllowUserToAddRows = false;
            this.dataGridView6.AllowUserToDeleteRows = false;
            this.dataGridView6.AllowUserToResizeColumns = false;
            this.dataGridView6.AllowUserToResizeRows = false;
            this.dataGridView6.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column22,
            this.Column23,
            this.Column24,
            this.Column37,
            this.Column38,
            this.Column40,
            this.Column39,
            this.Column25});
            this.dataGridView6.Location = new System.Drawing.Point(24, 23);
            this.dataGridView6.Name = "dataGridView6";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView6.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView6.RowHeadersVisible = false;
            this.dataGridView6.RowTemplate.Height = 23;
            this.dataGridView6.Size = new System.Drawing.Size(418, 289);
            this.dataGridView6.TabIndex = 5;
            this.dataGridView6.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView6_CellContentClick);
            // 
            // Column22
            // 
            this.Column22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column22.HeaderText = "이름";
            this.Column22.Name = "Column22";
            // 
            // Column23
            // 
            this.Column23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column23.HeaderText = "출근시간";
            this.Column23.Name = "Column23";
            // 
            // Column24
            // 
            this.Column24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column24.HeaderText = "퇴근시간";
            this.Column24.Name = "Column24";
            // 
            // Column37
            // 
            this.Column37.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column37.HeaderText = "출근확인";
            this.Column37.Name = "Column37";
            // 
            // Column38
            // 
            this.Column38.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column38.HeaderText = "퇴근확인";
            this.Column38.Name = "Column38";
            // 
            // Column40
            // 
            this.Column40.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column40.HeaderText = "근무일수";
            this.Column40.Name = "Column40";
            // 
            // Column39
            // 
            this.Column39.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column39.HeaderText = "근무시간";
            this.Column39.Name = "Column39";
            // 
            // Column25
            // 
            this.Column25.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column25.HeaderText = "근무날짜";
            this.Column25.Name = "Column25";
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(463, 226);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(113, 39);
            this.button19.TabIndex = 4;
            this.button19.Text = "월차신청";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.button7.Location = new System.Drawing.Point(454, 25);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(150, 80);
            this.button7.TabIndex = 3;
            this.button7.Text = "출근";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Controls.Add(this.Daycontainer);
            this.panel13.Controls.Add(this.label13);
            this.panel13.Controls.Add(this.button18);
            this.panel13.Controls.Add(this.label16);
            this.panel13.Controls.Add(this.label14);
            this.panel13.Controls.Add(this.label15);
            this.panel13.Controls.Add(this.label17);
            this.panel13.Controls.Add(this.label18);
            this.panel13.Controls.Add(this.label19);
            this.panel13.Controls.Add(this.label20);
            this.panel13.Controls.Add(this.button17);
            this.panel13.Location = new System.Drawing.Point(624, 342);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(624, 438);
            this.panel13.TabIndex = 5;
            this.panel13.Paint += new System.Windows.Forms.PaintEventHandler(this.panel13_Paint);
            this.panel13.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel13_MouseClick);
            // 
            // Daycontainer
            // 
            this.Daycontainer.Controls.Add(this.panel15);
            this.Daycontainer.Controls.Add(this.panel16);
            this.Daycontainer.Controls.Add(this.panel17);
            this.Daycontainer.Controls.Add(this.panel18);
            this.Daycontainer.Controls.Add(this.panel19);
            this.Daycontainer.Controls.Add(this.panel21);
            this.Daycontainer.Controls.Add(this.panel20);
            this.Daycontainer.Controls.Add(this.panel29);
            this.Daycontainer.Controls.Add(this.panel42);
            this.Daycontainer.Controls.Add(this.panel41);
            this.Daycontainer.Controls.Add(this.panel40);
            this.Daycontainer.Controls.Add(this.panel39);
            this.Daycontainer.Controls.Add(this.panel38);
            this.Daycontainer.Controls.Add(this.panel37);
            this.Daycontainer.Controls.Add(this.panel36);
            this.Daycontainer.Controls.Add(this.panel35);
            this.Daycontainer.Controls.Add(this.panel34);
            this.Daycontainer.Controls.Add(this.panel33);
            this.Daycontainer.Controls.Add(this.panel32);
            this.Daycontainer.Controls.Add(this.panel31);
            this.Daycontainer.Controls.Add(this.panel30);
            this.Daycontainer.Controls.Add(this.panel43);
            this.Daycontainer.Controls.Add(this.panel56);
            this.Daycontainer.Controls.Add(this.panel55);
            this.Daycontainer.Controls.Add(this.panel54);
            this.Daycontainer.Controls.Add(this.panel53);
            this.Daycontainer.Controls.Add(this.panel52);
            this.Daycontainer.Controls.Add(this.panel51);
            this.Daycontainer.Controls.Add(this.panel50);
            this.Daycontainer.Controls.Add(this.panel49);
            this.Daycontainer.Controls.Add(this.panel48);
            this.Daycontainer.Controls.Add(this.panel47);
            this.Daycontainer.Controls.Add(this.panel46);
            this.Daycontainer.Controls.Add(this.panel45);
            this.Daycontainer.Controls.Add(this.panel44);
            this.Daycontainer.Controls.Add(this.panel22);
            this.Daycontainer.Controls.Add(this.panel28);
            this.Daycontainer.Controls.Add(this.panel27);
            this.Daycontainer.Controls.Add(this.panel26);
            this.Daycontainer.Controls.Add(this.panel25);
            this.Daycontainer.Controls.Add(this.panel24);
            this.Daycontainer.Controls.Add(this.panel23);
            this.Daycontainer.Location = new System.Drawing.Point(38, 78);
            this.Daycontainer.Name = "Daycontainer";
            this.Daycontainer.Size = new System.Drawing.Size(553, 339);
            this.Daycontainer.TabIndex = 43;
            this.Daycontainer.Paint += new System.Windows.Forms.PaintEventHandler(this.Daycontainer_Paint);
            // 
            // panel15
            // 
            this.panel15.AutoSize = true;
            this.panel15.BackColor = System.Drawing.SystemColors.Info;
            this.panel15.Location = new System.Drawing.Point(3, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(0, 0);
            this.panel15.TabIndex = 0;
            // 
            // panel16
            // 
            this.panel16.AutoSize = true;
            this.panel16.BackColor = System.Drawing.SystemColors.Info;
            this.panel16.Location = new System.Drawing.Point(9, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(0, 0);
            this.panel16.TabIndex = 1;
            // 
            // panel17
            // 
            this.panel17.AutoSize = true;
            this.panel17.BackColor = System.Drawing.SystemColors.Info;
            this.panel17.Location = new System.Drawing.Point(15, 3);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(0, 0);
            this.panel17.TabIndex = 2;
            // 
            // panel18
            // 
            this.panel18.AutoSize = true;
            this.panel18.BackColor = System.Drawing.SystemColors.Info;
            this.panel18.Location = new System.Drawing.Point(21, 3);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(0, 0);
            this.panel18.TabIndex = 3;
            // 
            // panel19
            // 
            this.panel19.AutoSize = true;
            this.panel19.BackColor = System.Drawing.SystemColors.Info;
            this.panel19.Location = new System.Drawing.Point(27, 3);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(0, 0);
            this.panel19.TabIndex = 4;
            // 
            // panel21
            // 
            this.panel21.AutoSize = true;
            this.panel21.BackColor = System.Drawing.SystemColors.Info;
            this.panel21.Location = new System.Drawing.Point(33, 3);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(0, 0);
            this.panel21.TabIndex = 6;
            // 
            // panel20
            // 
            this.panel20.AutoSize = true;
            this.panel20.BackColor = System.Drawing.SystemColors.Info;
            this.panel20.Location = new System.Drawing.Point(39, 3);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(0, 0);
            this.panel20.TabIndex = 5;
            // 
            // panel29
            // 
            this.panel29.AutoSize = true;
            this.panel29.BackColor = System.Drawing.SystemColors.Info;
            this.panel29.Location = new System.Drawing.Point(45, 3);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(0, 0);
            this.panel29.TabIndex = 14;
            // 
            // panel42
            // 
            this.panel42.AutoSize = true;
            this.panel42.BackColor = System.Drawing.SystemColors.Info;
            this.panel42.Location = new System.Drawing.Point(51, 3);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(0, 0);
            this.panel42.TabIndex = 22;
            // 
            // panel41
            // 
            this.panel41.AutoSize = true;
            this.panel41.BackColor = System.Drawing.SystemColors.Info;
            this.panel41.Location = new System.Drawing.Point(57, 3);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(0, 0);
            this.panel41.TabIndex = 23;
            // 
            // panel40
            // 
            this.panel40.AutoSize = true;
            this.panel40.BackColor = System.Drawing.SystemColors.Info;
            this.panel40.Location = new System.Drawing.Point(63, 3);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(0, 0);
            this.panel40.TabIndex = 24;
            // 
            // panel39
            // 
            this.panel39.AutoSize = true;
            this.panel39.BackColor = System.Drawing.SystemColors.Info;
            this.panel39.Location = new System.Drawing.Point(69, 3);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(0, 0);
            this.panel39.TabIndex = 25;
            // 
            // panel38
            // 
            this.panel38.AutoSize = true;
            this.panel38.BackColor = System.Drawing.SystemColors.Info;
            this.panel38.Location = new System.Drawing.Point(75, 3);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(0, 0);
            this.panel38.TabIndex = 27;
            // 
            // panel37
            // 
            this.panel37.AutoSize = true;
            this.panel37.BackColor = System.Drawing.SystemColors.Info;
            this.panel37.Location = new System.Drawing.Point(81, 3);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(0, 0);
            this.panel37.TabIndex = 26;
            // 
            // panel36
            // 
            this.panel36.AutoSize = true;
            this.panel36.BackColor = System.Drawing.SystemColors.Info;
            this.panel36.Location = new System.Drawing.Point(87, 3);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(0, 0);
            this.panel36.TabIndex = 21;
            // 
            // panel35
            // 
            this.panel35.AutoSize = true;
            this.panel35.BackColor = System.Drawing.SystemColors.Info;
            this.panel35.Location = new System.Drawing.Point(93, 3);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(0, 0);
            this.panel35.TabIndex = 19;
            // 
            // panel34
            // 
            this.panel34.AutoSize = true;
            this.panel34.BackColor = System.Drawing.SystemColors.Info;
            this.panel34.Location = new System.Drawing.Point(99, 3);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(0, 0);
            this.panel34.TabIndex = 20;
            // 
            // panel33
            // 
            this.panel33.AutoSize = true;
            this.panel33.BackColor = System.Drawing.SystemColors.Info;
            this.panel33.Location = new System.Drawing.Point(105, 3);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(0, 0);
            this.panel33.TabIndex = 18;
            // 
            // panel32
            // 
            this.panel32.AutoSize = true;
            this.panel32.BackColor = System.Drawing.SystemColors.Info;
            this.panel32.Location = new System.Drawing.Point(111, 3);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(0, 0);
            this.panel32.TabIndex = 17;
            // 
            // panel31
            // 
            this.panel31.AutoSize = true;
            this.panel31.BackColor = System.Drawing.SystemColors.Info;
            this.panel31.Location = new System.Drawing.Point(117, 3);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(0, 0);
            this.panel31.TabIndex = 16;
            // 
            // panel30
            // 
            this.panel30.AutoSize = true;
            this.panel30.BackColor = System.Drawing.SystemColors.Info;
            this.panel30.Location = new System.Drawing.Point(123, 3);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(0, 0);
            this.panel30.TabIndex = 15;
            // 
            // panel43
            // 
            this.panel43.AutoSize = true;
            this.panel43.BackColor = System.Drawing.SystemColors.Info;
            this.panel43.Location = new System.Drawing.Point(129, 3);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(0, 0);
            this.panel43.TabIndex = 28;
            // 
            // panel56
            // 
            this.panel56.AutoSize = true;
            this.panel56.BackColor = System.Drawing.SystemColors.Info;
            this.panel56.Location = new System.Drawing.Point(135, 3);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(0, 0);
            this.panel56.TabIndex = 29;
            // 
            // panel55
            // 
            this.panel55.AutoSize = true;
            this.panel55.BackColor = System.Drawing.SystemColors.Info;
            this.panel55.Location = new System.Drawing.Point(141, 3);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(0, 0);
            this.panel55.TabIndex = 30;
            // 
            // panel54
            // 
            this.panel54.AutoSize = true;
            this.panel54.BackColor = System.Drawing.SystemColors.Info;
            this.panel54.Location = new System.Drawing.Point(147, 3);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(0, 0);
            this.panel54.TabIndex = 31;
            // 
            // panel53
            // 
            this.panel53.AutoSize = true;
            this.panel53.BackColor = System.Drawing.SystemColors.Info;
            this.panel53.Location = new System.Drawing.Point(153, 3);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(0, 0);
            this.panel53.TabIndex = 32;
            // 
            // panel52
            // 
            this.panel52.AutoSize = true;
            this.panel52.BackColor = System.Drawing.SystemColors.Info;
            this.panel52.Location = new System.Drawing.Point(159, 3);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(0, 0);
            this.panel52.TabIndex = 34;
            // 
            // panel51
            // 
            this.panel51.AutoSize = true;
            this.panel51.BackColor = System.Drawing.SystemColors.Info;
            this.panel51.Location = new System.Drawing.Point(165, 3);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(0, 0);
            this.panel51.TabIndex = 33;
            // 
            // panel50
            // 
            this.panel50.AutoSize = true;
            this.panel50.BackColor = System.Drawing.SystemColors.Info;
            this.panel50.Location = new System.Drawing.Point(171, 3);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(0, 0);
            this.panel50.TabIndex = 35;
            // 
            // panel49
            // 
            this.panel49.AutoSize = true;
            this.panel49.BackColor = System.Drawing.SystemColors.Info;
            this.panel49.Location = new System.Drawing.Point(177, 3);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(0, 0);
            this.panel49.TabIndex = 40;
            // 
            // panel48
            // 
            this.panel48.AutoSize = true;
            this.panel48.BackColor = System.Drawing.SystemColors.Info;
            this.panel48.Location = new System.Drawing.Point(183, 3);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(0, 0);
            this.panel48.TabIndex = 41;
            // 
            // panel47
            // 
            this.panel47.AutoSize = true;
            this.panel47.BackColor = System.Drawing.SystemColors.Info;
            this.panel47.Location = new System.Drawing.Point(189, 3);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(0, 0);
            this.panel47.TabIndex = 39;
            // 
            // panel46
            // 
            this.panel46.AutoSize = true;
            this.panel46.BackColor = System.Drawing.SystemColors.Info;
            this.panel46.Location = new System.Drawing.Point(195, 3);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(0, 0);
            this.panel46.TabIndex = 38;
            // 
            // panel45
            // 
            this.panel45.AutoSize = true;
            this.panel45.BackColor = System.Drawing.SystemColors.Info;
            this.panel45.Location = new System.Drawing.Point(201, 3);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(0, 0);
            this.panel45.TabIndex = 37;
            // 
            // panel44
            // 
            this.panel44.AutoSize = true;
            this.panel44.BackColor = System.Drawing.SystemColors.Info;
            this.panel44.Location = new System.Drawing.Point(207, 3);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(0, 0);
            this.panel44.TabIndex = 36;
            // 
            // panel22
            // 
            this.panel22.AutoSize = true;
            this.panel22.BackColor = System.Drawing.SystemColors.Info;
            this.panel22.Location = new System.Drawing.Point(213, 3);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(0, 0);
            this.panel22.TabIndex = 7;
            // 
            // panel28
            // 
            this.panel28.AutoSize = true;
            this.panel28.BackColor = System.Drawing.SystemColors.Info;
            this.panel28.Location = new System.Drawing.Point(219, 3);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(0, 0);
            this.panel28.TabIndex = 12;
            // 
            // panel27
            // 
            this.panel27.AutoSize = true;
            this.panel27.BackColor = System.Drawing.SystemColors.Info;
            this.panel27.Location = new System.Drawing.Point(225, 3);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(0, 0);
            this.panel27.TabIndex = 13;
            // 
            // panel26
            // 
            this.panel26.AutoSize = true;
            this.panel26.BackColor = System.Drawing.SystemColors.Info;
            this.panel26.Location = new System.Drawing.Point(231, 3);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(0, 0);
            this.panel26.TabIndex = 11;
            // 
            // panel25
            // 
            this.panel25.AutoSize = true;
            this.panel25.BackColor = System.Drawing.SystemColors.Info;
            this.panel25.Location = new System.Drawing.Point(237, 3);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(0, 0);
            this.panel25.TabIndex = 10;
            // 
            // panel24
            // 
            this.panel24.AutoSize = true;
            this.panel24.BackColor = System.Drawing.SystemColors.Info;
            this.panel24.Location = new System.Drawing.Point(243, 3);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(0, 0);
            this.panel24.TabIndex = 9;
            // 
            // panel23
            // 
            this.panel23.AutoSize = true;
            this.panel23.BackColor = System.Drawing.SystemColors.Info;
            this.panel23.Location = new System.Drawing.Point(249, 3);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(0, 0);
            this.panel23.TabIndex = 8;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.Location = new System.Drawing.Point(229, 7);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(149, 29);
            this.label13.TabIndex = 42;
            this.label13.Text = "Month YEAR";
            // 
            // button18
            // 
            this.button18.FlatAppearance.BorderSize = 0;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Location = new System.Drawing.Point(10, 8);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(87, 39);
            this.button18.TabIndex = 41;
            this.button18.Text = "지난달";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click_1);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.Location = new System.Drawing.Point(58, 45);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(32, 29);
            this.label16.TabIndex = 21;
            this.label16.Text = "일";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.Location = new System.Drawing.Point(518, 44);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(32, 29);
            this.label14.TabIndex = 20;
            this.label14.Text = "토";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.Location = new System.Drawing.Point(443, 44);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(32, 29);
            this.label15.TabIndex = 19;
            this.label15.Text = "금";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label17.Location = new System.Drawing.Point(369, 45);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(32, 29);
            this.label17.TabIndex = 18;
            this.label17.Text = "목";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label18.Location = new System.Drawing.Point(293, 45);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(32, 29);
            this.label18.TabIndex = 17;
            this.label18.Text = "수";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label19.Location = new System.Drawing.Point(216, 45);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(32, 29);
            this.label19.TabIndex = 16;
            this.label19.Text = "화";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label20.Location = new System.Drawing.Point(137, 45);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(32, 29);
            this.label20.TabIndex = 15;
            this.label20.Text = "월";
            // 
            // button17
            // 
            this.button17.FlatAppearance.BorderSize = 0;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(525, 8);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(87, 39);
            this.button17.TabIndex = 40;
            this.button17.Text = "다음달";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click_1);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Controls.Add(this.dataGridView3);
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(625, 780);
            this.panel12.TabIndex = 4;
            this.panel12.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel12_MouseClick);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column19,
            this.Column20,
            this.Column21});
            this.dataGridView3.Location = new System.Drawing.Point(18, 13);
            this.dataGridView3.Name = "dataGridView3";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView3.RowHeadersVisible = false;
            this.dataGridView3.RowTemplate.Height = 23;
            this.dataGridView3.Size = new System.Drawing.Size(591, 752);
            this.dataGridView3.TabIndex = 5;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column1.HeaderText = "이름";
            this.Column1.Name = "Column1";
            this.Column1.Width = 69;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column2.HeaderText = "나이";
            this.Column2.Name = "Column2";
            this.Column2.Width = 69;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "주민번호";
            this.Column3.Name = "Column3";
            // 
            // Column19
            // 
            this.Column19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column19.HeaderText = "전화번호";
            this.Column19.Name = "Column19";
            // 
            // Column20
            // 
            this.Column20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column20.HeaderText = "주소";
            this.Column20.Name = "Column20";
            this.Column20.Width = 69;
            // 
            // Column21
            // 
            this.Column21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column21.HeaderText = "예약날짜";
            this.Column21.Name = "Column21";
            // 
            // panel4
            // 
            this.panel4.AutoSize = true;
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel4.Controls.Add(this.panel10);
            this.panel4.Controls.Add(this.tabControl2);
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel9);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(323, 65);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1250, 780);
            this.panel4.TabIndex = 6;
            this.panel4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel4_MouseClick);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.panel4_1);
            this.panel10.Location = new System.Drawing.Point(314, 1);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(933, 233);
            this.panel10.TabIndex = 22;
            // 
            // panel4_1
            // 
            this.panel4_1.BackColor = System.Drawing.Color.White;
            this.panel4_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4_1.Controls.Add(this.button4_1_1);
            this.panel4_1.Controls.Add(this.textBox4_1_7);
            this.panel4_1.Controls.Add(this.textBox4_1_6);
            this.panel4_1.Controls.Add(this.label28);
            this.panel4_1.Controls.Add(this.label27);
            this.panel4_1.Controls.Add(this.textBox4_1_5);
            this.panel4_1.Controls.Add(this.label23);
            this.panel4_1.Controls.Add(this.panel4_1_1);
            this.panel4_1.Controls.Add(this.textBox4_1_4);
            this.panel4_1.Controls.Add(this.textBox4_1_3);
            this.panel4_1.Controls.Add(this.textBox4_1_2);
            this.panel4_1.Controls.Add(this.textBox4_1_1);
            this.panel4_1.Controls.Add(this.label26);
            this.panel4_1.Controls.Add(this.label25);
            this.panel4_1.Controls.Add(this.label24);
            this.panel4_1.Controls.Add(this.label);
            this.panel4_1.Location = new System.Drawing.Point(11, 10);
            this.panel4_1.Name = "panel4_1";
            this.panel4_1.Size = new System.Drawing.Size(913, 212);
            this.panel4_1.TabIndex = 3;
            this.panel4_1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel4_1_MouseClick);
            // 
            // button4_1_1
            // 
            this.button4_1_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4_1_1.Location = new System.Drawing.Point(619, 170);
            this.button4_1_1.Name = "button4_1_1";
            this.button4_1_1.Size = new System.Drawing.Size(80, 30);
            this.button4_1_1.TabIndex = 19;
            this.button4_1_1.Text = "수정";
            this.button4_1_1.UseVisualStyleBackColor = true;
            // 
            // textBox4_1_7
            // 
            this.textBox4_1_7.Location = new System.Drawing.Point(504, 109);
            this.textBox4_1_7.Name = "textBox4_1_7";
            this.textBox4_1_7.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_7.TabIndex = 18;
            // 
            // textBox4_1_6
            // 
            this.textBox4_1_6.Location = new System.Drawing.Point(505, 59);
            this.textBox4_1_6.Name = "textBox4_1_6";
            this.textBox4_1_6.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_6.TabIndex = 17;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label28.Location = new System.Drawing.Point(389, 116);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(46, 22);
            this.label28.TabIndex = 15;
            this.label28.Text = "성별";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label27.Location = new System.Drawing.Point(387, 67);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(64, 22);
            this.label27.TabIndex = 14;
            this.label27.Text = "이메일";
            // 
            // textBox4_1_5
            // 
            this.textBox4_1_5.Location = new System.Drawing.Point(505, 11);
            this.textBox4_1_5.Name = "textBox4_1_5";
            this.textBox4_1_5.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_5.TabIndex = 13;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label23.Location = new System.Drawing.Point(387, 19);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(64, 22);
            this.label23.TabIndex = 12;
            this.label23.Text = "입사일";
            // 
            // panel4_1_1
            // 
            this.panel4_1_1.Location = new System.Drawing.Point(710, 5);
            this.panel4_1_1.Name = "panel4_1_1";
            this.panel4_1_1.Size = new System.Drawing.Size(192, 199);
            this.panel4_1_1.TabIndex = 11;
            // 
            // textBox4_1_4
            // 
            this.textBox4_1_4.Location = new System.Drawing.Point(168, 160);
            this.textBox4_1_4.Name = "textBox4_1_4";
            this.textBox4_1_4.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_4.TabIndex = 10;
            // 
            // textBox4_1_3
            // 
            this.textBox4_1_3.Location = new System.Drawing.Point(168, 109);
            this.textBox4_1_3.Name = "textBox4_1_3";
            this.textBox4_1_3.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_3.TabIndex = 9;
            // 
            // textBox4_1_2
            // 
            this.textBox4_1_2.Location = new System.Drawing.Point(168, 59);
            this.textBox4_1_2.Name = "textBox4_1_2";
            this.textBox4_1_2.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_2.TabIndex = 8;
            // 
            // textBox4_1_1
            // 
            this.textBox4_1_1.Location = new System.Drawing.Point(168, 11);
            this.textBox4_1_1.Name = "textBox4_1_1";
            this.textBox4_1_1.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_1.TabIndex = 7;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label26.Location = new System.Drawing.Point(17, 167);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(82, 22);
            this.label26.TabIndex = 6;
            this.label26.Text = "전화번호";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label25.Location = new System.Drawing.Point(17, 116);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(46, 22);
            this.label25.TabIndex = 5;
            this.label25.Text = "주소";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label24.Location = new System.Drawing.Point(17, 67);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(82, 22);
            this.label24.TabIndex = 4;
            this.label24.Text = "주민번호";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.label.Location = new System.Drawing.Point(18, 19);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(46, 22);
            this.label.TabIndex = 3;
            this.label.Text = "이름";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Location = new System.Drawing.Point(322, 244);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(918, 526);
            this.tabControl2.TabIndex = 4;
            this.tabControl2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabControl2_MouseClick);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView4_2);
            this.tabPage3.Location = new System.Drawing.Point(4, 34);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(910, 488);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "월급내역";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView4_2
            // 
            this.dataGridView4_2.AllowUserToAddRows = false;
            this.dataGridView4_2.AllowUserToDeleteRows = false;
            this.dataGridView4_2.AllowUserToResizeRows = false;
            this.dataGridView4_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4_2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column32,
            this.Column26,
            this.Column27,
            this.Column28,
            this.Column29,
            this.Column31,
            this.Column30});
            this.dataGridView4_2.Location = new System.Drawing.Point(1, 1);
            this.dataGridView4_2.Name = "dataGridView4_2";
            this.dataGridView4_2.RowHeadersVisible = false;
            this.dataGridView4_2.RowTemplate.Height = 23;
            this.dataGridView4_2.Size = new System.Drawing.Size(909, 488);
            this.dataGridView4_2.TabIndex = 0;
            this.dataGridView4_2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView4_2_MouseClick);
            // 
            // Column32
            // 
            this.Column32.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column32.HeaderText = "날짜";
            this.Column32.Name = "Column32";
            this.Column32.ReadOnly = true;
            // 
            // Column26
            // 
            this.Column26.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column26.HeaderText = "근무일수";
            this.Column26.Name = "Column26";
            this.Column26.ReadOnly = true;
            this.Column26.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Column27
            // 
            this.Column27.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column27.HeaderText = "근무시간";
            this.Column27.Name = "Column27";
            this.Column27.ReadOnly = true;
            this.Column27.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Column28
            // 
            this.Column28.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column28.HeaderText = "은행명";
            this.Column28.Name = "Column28";
            this.Column28.ReadOnly = true;
            this.Column28.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Column29
            // 
            this.Column29.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column29.HeaderText = "계좌번호";
            this.Column29.Name = "Column29";
            this.Column29.ReadOnly = true;
            this.Column29.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Column31
            // 
            this.Column31.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column31.HeaderText = "예금주";
            this.Column31.Name = "Column31";
            this.Column31.ReadOnly = true;
            this.Column31.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Column30
            // 
            this.Column30.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column30.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column30.HeaderText = "확인";
            this.Column30.Name = "Column30";
            this.Column30.ReadOnly = true;
            this.Column30.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column30.Width = 69;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 34);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(910, 488);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "근태조회";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panel4_2);
            this.tabPage5.Location = new System.Drawing.Point(4, 34);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(910, 488);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "재직증명서";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel4_2
            // 
            this.panel4_2.BackColor = System.Drawing.Color.Silver;
            this.panel4_2.Controls.Add(this.button4_2);
            this.panel4_2.Controls.Add(this.label30);
            this.panel4_2.Location = new System.Drawing.Point(3, 3);
            this.panel4_2.Name = "panel4_2";
            this.panel4_2.Size = new System.Drawing.Size(921, 491);
            this.panel4_2.TabIndex = 0;
            // 
            // button4_2
            // 
            this.button4_2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4_2.Location = new System.Drawing.Point(848, 13);
            this.button4_2.Name = "button4_2";
            this.button4_2.Size = new System.Drawing.Size(60, 37);
            this.button4_2.TabIndex = 2;
            this.button4_2.Text = "인쇄";
            this.button4_2.UseVisualStyleBackColor = true;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(376, 17);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(172, 37);
            this.label30.TabIndex = 1;
            this.label30.Text = "재직증명서";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button4_3);
            this.tabPage6.Controls.Add(this.label29);
            this.tabPage6.Controls.Add(this.dataGridView4_4);
            this.tabPage6.Location = new System.Drawing.Point(4, 34);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabPage6.Size = new System.Drawing.Size(910, 488);
            this.tabPage6.TabIndex = 3;
            this.tabPage6.Text = "결재";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button4_3
            // 
            this.button4_3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4_3.Location = new System.Drawing.Point(347, 457);
            this.button4_3.Name = "button4_3";
            this.button4_3.Size = new System.Drawing.Size(93, 31);
            this.button4_3.TabIndex = 4;
            this.button4_3.Text = "결제";
            this.button4_3.UseVisualStyleBackColor = true;
            this.button4_3.Click += new System.EventHandler(this.button4_3_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(12, 10);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(96, 24);
            this.label29.TabIndex = 1;
            this.label29.Text = "물품 결재";
            // 
            // dataGridView4_4
            // 
            this.dataGridView4_4.AllowUserToAddRows = false;
            this.dataGridView4_4.AllowUserToDeleteRows = false;
            this.dataGridView4_4.AllowUserToResizeRows = false;
            this.dataGridView4_4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4_4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column33,
            this.Column34,
            this.Column35,
            this.Column36});
            this.dataGridView4_4.Location = new System.Drawing.Point(3, 41);
            this.dataGridView4_4.Name = "dataGridView4_4";
            this.dataGridView4_4.RowHeadersVisible = false;
            this.dataGridView4_4.RowTemplate.Height = 23;
            this.dataGridView4_4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView4_4.Size = new System.Drawing.Size(437, 411);
            this.dataGridView4_4.TabIndex = 0;
            this.dataGridView4_4.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView4_4_ColumnHeaderMouseClick);
            // 
            // Column33
            // 
            this.Column33.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column33.HeaderText = "제품명";
            this.Column33.Name = "Column33";
            this.Column33.ReadOnly = true;
            this.Column33.Width = 85;
            // 
            // Column34
            // 
            this.Column34.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column34.HeaderText = "수량";
            this.Column34.Name = "Column34";
            this.Column34.ReadOnly = true;
            this.Column34.Width = 69;
            // 
            // Column35
            // 
            this.Column35.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column35.HeaderText = "결재시간";
            this.Column35.Name = "Column35";
            this.Column35.ReadOnly = true;
            // 
            // Column36
            // 
            this.Column36.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column36.HeaderText = "선택";
            this.Column36.Name = "Column36";
            this.Column36.Width = 50;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.button4_1);
            this.panel7.Controls.Add(this.dataGridView4_1);
            this.panel7.Location = new System.Drawing.Point(1, 1);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(314, 776);
            this.panel7.TabIndex = 20;
            // 
            // button4_1
            // 
            this.button4_1.Location = new System.Drawing.Point(194, 720);
            this.button4_1.Name = "button4_1";
            this.button4_1.Size = new System.Drawing.Size(97, 35);
            this.button4_1.TabIndex = 6;
            this.button4_1.Text = "신규";
            this.button4_1.UseVisualStyleBackColor = true;
            this.button4_1.Click += new System.EventHandler(this.button4_1_Click);
            // 
            // dataGridView4_1
            // 
            this.dataGridView4_1.AllowUserToAddRows = false;
            this.dataGridView4_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4_1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column4,
            this.Column10});
            this.dataGridView4_1.Location = new System.Drawing.Point(12, 14);
            this.dataGridView4_1.Name = "dataGridView4_1";
            this.dataGridView4_1.RowHeadersVisible = false;
            this.dataGridView4_1.RowTemplate.Height = 23;
            this.dataGridView4_1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView4_1.Size = new System.Drawing.Size(290, 752);
            this.dataGridView4_1.TabIndex = 5;
            this.dataGridView4_1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_1_CellClick);
            this.dataGridView4_1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView4_1_MouseClick);
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.HeaderText = "직원이름";
            this.Column4.Name = "Column4";
            // 
            // Column10
            // 
            this.Column10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column10.HeaderText = "직급";
            this.Column10.Name = "Column10";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Location = new System.Drawing.Point(314, 232);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(933, 545);
            this.panel9.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(16, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Name";
            this.label1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.label1_MouseClick);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(1238, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Date";
            this.label2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.label2_MouseClick);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.LightGray;
            this.panel8.Controls.Add(this.dataGridView2);
            this.panel8.Controls.Add(this.button12);
            this.panel8.Controls.Add(this.button8);
            this.panel8.Controls.Add(this.label9);
            this.panel8.Location = new System.Drawing.Point(325, 49);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(697, 663);
            this.panel8.TabIndex = 12;
            this.panel8.Visible = false;
            this.panel8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel8_MouseClick);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9});
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(697, 663);
            this.dataGridView2.TabIndex = 14;
            this.dataGridView2.DoubleClick += new System.EventHandler(this.dataGridView2_DoubleClick);
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column5.HeaderText = "이름";
            this.Column5.Name = "Column5";
            this.Column5.Width = 69;
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column6.HeaderText = "나이";
            this.Column6.Name = "Column6";
            this.Column6.Width = 69;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column7.HeaderText = "생년월일";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column8.HeaderText = "핸드폰번호";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column9.HeaderText = "주소";
            this.Column9.Name = "Column9";
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.White;
            this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(474, 613);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(100, 35);
            this.button12.TabIndex = 16;
            this.button12.TabStop = false;
            this.button12.Text = "수정";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 25);
            this.label9.TabIndex = 13;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(17, 115);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(291, 732);
            this.tabControl1.TabIndex = 17;
            this.tabControl1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabControl1_MouseClick);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Location = new System.Drawing.Point(4, 34);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(283, 694);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "진료대기";
            this.tabPage1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabPage1_MouseClick);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 656);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(172, 25);
            this.label22.TabIndex = 1;
            this.label22.Text = "진료2실 대기인원 : 0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(5, 625);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(178, 25);
            this.label21.TabIndex = 0;
            this.label21.Text = "진료1실 대기인원 : 0 ";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(283, 706);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "진료완료";
            this.tabPage2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabPage2_MouseClick);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 10F);
            this.button1.Location = new System.Drawing.Point(12, 69);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 40);
            this.button1.TabIndex = 1;
            this.button1.Text = "환자";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(1028, 16);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 33);
            this.button5.TabIndex = 11;
            this.button5.TabStop = false;
            this.button5.Text = "검색";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            this.button5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.button5_KeyDown);
            // 
            // main_textBox1
            // 
            this.main_textBox1.Location = new System.Drawing.Point(325, 17);
            this.main_textBox1.Name = "main_textBox1";
            this.main_textBox1.Size = new System.Drawing.Size(700, 31);
            this.main_textBox1.TabIndex = 8;
            this.main_textBox1.TabStop = false;
            this.main_textBox1.Click += new System.EventHandler(this.main_textBox1_Click);
            this.main_textBox1.TextChanged += new System.EventHandler(this.Form_main_Load);
            this.main_textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.main_textBox1_KeyDown);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel5.Controls.Add(this.label2);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Location = new System.Drawing.Point(12, 6);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1558, 53);
            this.panel5.TabIndex = 16;
            this.panel5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel5_MouseClick);
            // 
            // Form_main
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1584, 861);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.main_textBox1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel5);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Name = "Form_main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ERP";
            this.Load += new System.EventHandler(this.Form_main_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form_main_MouseClick);
            this.panel1.ResumeLayout(false);
            this.panel1_2.ResumeLayout(false);
            this.panel1_2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel1_3.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.panel1_1.ResumeLayout(false);
            this.panel1_1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3_2.ResumeLayout(false);
            this.panel3_2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3_2_1)).EndInit();
            this.panel3_3.ResumeLayout(false);
            this.panel3_3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3_3_1)).EndInit();
            this.panel3_1.ResumeLayout(false);
            this.panel3_1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.Daycontainer.ResumeLayout(false);
            this.Daycontainer.PerformLayout();
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel4_1.ResumeLayout(false);
            this.panel4_1.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_2)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.panel4_2.ResumeLayout(false);
            this.panel4_2.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_4)).EndInit();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_1)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel3_2;
        private System.Windows.Forms.Button button3_1_3;
        private System.Windows.Forms.Button button3_2_1;
        public System.Windows.Forms.TextBox textBox3_2_1;
        private System.Windows.Forms.Panel panel3_3;
        private System.Windows.Forms.Panel panel3_1;
        private System.Windows.Forms.Button button3_1_1;
        public System.Windows.Forms.TextBox textBox3_1_1;
        private System.Windows.Forms.Button button3_2_2;
        private System.Windows.Forms.Button button3_3_3;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button8;
        public System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label3_1_1;
        private System.Windows.Forms.Label label3_3_1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Panel panel1_3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Panel panel1_1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel1_2;
        public System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Button button6;
        public System.Windows.Forms.TextBox textBox6;
        public System.Windows.Forms.TextBox textBox5;
        public System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button7;
        public System.Windows.Forms.DataGridView dataGridView3_2_1;
        private System.Windows.Forms.Button button5;
        public System.Windows.Forms.TextBox main_textBox1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button19;
        public System.Windows.Forms.DataGridView dataGridView3_3_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column14;
        public System.Windows.Forms.TextBox textBox3_3_1;
        private System.Windows.Forms.Button button3_3_2;
        private System.Windows.Forms.Button button3_3_1;
        public System.Windows.Forms.Label label3_2_1;
        public System.Windows.Forms.Label label3_3_2;
        public System.Windows.Forms.TabPage tabPage1;
        public System.Windows.Forms.Label label22;
        public System.Windows.Forms.Label label21;
        public System.Windows.Forms.TabPage tabPage2;
        public System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.FlowLayoutPanel Daycontainer;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Button button3_1_2;
        public System.Windows.Forms.TextBox textBox3_1_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewButtonColumn Column17;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column18;
        public System.Windows.Forms.Label label3_1_2;
        private System.Windows.Forms.Label label3_1_3;
        private System.Windows.Forms.Label label3_1_4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        public System.Windows.Forms.DataGridView dataGridView4_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column32;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column26;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column27;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column28;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column29;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column31;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column30;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel panel4_2;
        private System.Windows.Forms.Button button4_2;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button button4_3;
        private System.Windows.Forms.Label label29;
        public System.Windows.Forms.DataGridView dataGridView4_4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column33;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column34;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column35;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column36;
        private System.Windows.Forms.Panel panel4_1;
        private System.Windows.Forms.Button button4_1_1;
        public System.Windows.Forms.TextBox textBox4_1_7;
        public System.Windows.Forms.TextBox textBox4_1_6;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        public System.Windows.Forms.TextBox textBox4_1_5;
        private System.Windows.Forms.Label label23;
        public System.Windows.Forms.Panel panel4_1_1;
        public System.Windows.Forms.TextBox textBox4_1_4;
        public System.Windows.Forms.TextBox textBox4_1_3;
        public System.Windows.Forms.TextBox textBox4_1_2;
        public System.Windows.Forms.TextBox textBox4_1_1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label;
        public System.Windows.Forms.DataGridView dataGridView4_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.Button button4_1;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column37;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column38;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column40;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column39;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        public System.Windows.Forms.Panel panel8;
        public System.Windows.Forms.Button button12;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
    }
}