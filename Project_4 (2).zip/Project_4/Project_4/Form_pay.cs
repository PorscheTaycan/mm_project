﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_4
{
    public partial class Form_pay : Form
    {
        static Random random = new Random();   // 랜덤 수 생성
        //Form_login.Form_main form_Main = new form_main(this);
        
        public Form_pay(string[] rowdata)
        {
            InitializeComponent();
            // 현재 DataGridView에 있는 모든 행 삭제
            //dataGridView1.Rows.Clear();
            string ManageFilePath = "PayData.txt"; // 환자 정보 파일 경로
            string[] lines = File.ReadAllLines(ManageFilePath); // 파일의 모든 줄 읽기


            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();

            string str = "";
            try
            {
                // 수납 랜덤 수로 나오게 i < 10이거는 환자 카운트로 바꿔줘야 함

                int RanNum = random.Next(1000, 200000);
                str = string.Format("{0:#,###}", RanNum);

                DataGridViewCheckBoxCell dataGridViewCheckBoxCell = new DataGridViewCheckBoxCell();
                checkBoxColumn.HeaderText = "여부";
                dataGridView1.Columns.Add(checkBoxColumn);
                for (int i = 0; i < lines.Length; i++)
                {
                    string[] Pays = lines[i].Split('\t');
                    dataGridView1.Rows.Add(Pays[0], Pays[1], Pays[2]);

                }
                File.AppendAllText(ManageFilePath, rowdata[0] + "\t" + rowdata[2] + "\t" + str + "\t" + DateTime.Now.ToString("yyyy-MM-dd") + "\n");
            }




            catch (Exception ex)
            {
                MessageBox.Show("예외가 발생했습니다: " + ex.Message);
            }

        }
        


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form_pay_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Pay 폼이 닫힐 때 DataGridView의 데이터를 저장
            SaveDataGridViewData();
        }
        private void SaveDataGridViewData()
        {
/*            // 기존 행에 대해 랜덤 가격 설정
            for (int i = 0; i < 10; i++)
            {

                // 각 행을 반복하면서 데이터를 문자열에 추가합니다.
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        // 셀의 값을 가져와서 문자열에 추가합니다.
                        textData.Append(row.Cells[i].Value);

                        // 각 셀의 값 사이에 탭 문자를 삽입합니다.
                        if (i < dataGridView1.Columns.Count - 1)
                            textData.Append('\t');
                    }

                    // 각 행의 마지막에 줄 바꿈 문자를 삽입합니다.
                    textData.AppendLine();
                }

                // StringBuilder에 만들어진 텍스트 데이터를 텍스트 파일로 저장합니다.
                File.WriteAllText("PayData.txt", textData.ToString());

            }

        }
        private void LoadDataGridViewData()
        {
            // 저장된 텍스트 파일을 이용하여 DataGridView에 데이터를 설정합니다.
            if (File.Exists("DataGridViewData.txt"))
            {
                // 텍스트 파일을 줄 단위로 읽어옵니다.
                string[] lines = File.ReadAllLines("DataGridViewData.txt");

                // 각 줄을 DataGridView에 추가합니다.
                foreach (string line in lines)
                {
                    // 각 줄을 탭 문자로 분리하여 셀의 값으로 사용합니다.
                    string[] values = line.Split('\t');

                    // DataGridView에 행을 추가합니다.
                    dataGridView1.Rows.Add(values);
                }
            }*/
        }



        private void Form_pay_Load(object sender, EventArgs e)
        {

        }
    }
}
