﻿using Project_4;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Xml.Linq;
using static Project_4.Program;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;
// panel1: 초기화면-환자
// panel1_1: 당일 예약 환자
// panel1_2: 환자 신규 등록
// panel1_3: 그래프

// panel2: 초기화면-근태
// panel3: 초기화면-재고
// panel4: 초기화면-관리자
// panel5: 대기자 화면
// panel6: 진료실1
// panel7: 진료실2

namespace Project_4
{


    public partial class Form_main : Form
    {

        DateTime nextMonths = DateTime.Now.AddMonths(1);
        public static Form_inv_add form_inv_add;
        private Form_login form_login;
        int month, year;
        private DateTime clickedDatetime;
        private UserControldays clickedpanel;
        public static outpatient outpatient;
        public static Form_pay form_pay;
        string name;
        int workcount = 0;
        private Timer timer;
        public Form_main(Form_login form_login, bool auth, string Name, string Birth, string Rent)
        {
            this.name = Name;

            InitializeComponent();

            


            this.FormBorderStyle = FormBorderStyle.FixedSingle; // 화면 사이즈 변경 불가능
            MaximizeBox = false; // 최대화 불가능
            button4.Visible = auth;     // 관리자계정일때 보여주기
            if (auth == false)       // 간호사 계정일때
            {
                label1.Text = Name + " 간호사님 환영합니다.";
            }
            else
            {
                label1.Text = Name + " 님 환영합니다.";
            }
            this.form_login = form_login;



            List<List<string>> lines = Patient.Line();
            foreach (var patientData in lines)
            {
                string reservationDate = patientData.Last(); // 예약 날짜를 가져옴
                if (reservationDate == DateTime.Now.ToString("yyyy-MM-dd"))
                {
                    var patientInfo = string.Join("\t", patientData.Take(patientData.Count - 1)); // 마지막 예약 날짜를 제외하고 환자 정보를 가져오기

                    // 데이터그리드뷰 초기화
                    dataGridView1.Rows.Clear();
                    var patient_list = patientInfo.Split('\t');

                        for(int j= 0; j < lines.Count; j++)
                        {
                            dataGridView1.Rows.Add(patient_list[0], patient_list[1], patient_list[2], patient_list[3], patient_list[4]);
                        }


                }

            }

        
            DisplaDays();

        }
        private void DisplaDays()
        {

            DateTime now = DateTime.Now;
            month = now.Month;
            year = now.Year;
            string monthname = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);// 현재 월에 해당하는 달의 이름을 가져와서 라벨에 표시
            label13.Text = year + "년 " + monthname;

            DateTime startofthemonth = new DateTime(year, month, 1);// 현재 연도와 월에 해당하는 달의 시작 요일과 날짜 수를 계산
            int days = DateTime.DaysInMonth(year, month);
            int dayoftheweek = Convert.ToInt32(startofthemonth.DayOfWeek.ToString("d")) + 3;
            for (int i = 0; i < dayoftheweek; i++)  // 달력의 시작 부분에 공백을 추가
            {
                UserControl ucblank = new UserControlBlank();
                Daycontainer.Controls.Add(ucblank);
            }
            for (int i = 1; i <= days; i++)// 해당 월의 각 날짜를 패널에 추가
            {
                UserControldays ucdays = new UserControldays();
                ucdays.days(i);
                Daycontainer.Controls.Add(ucdays);


                ucdays.OnPanelClick += UserControlDays_OnPanelClick;// 클릭 이벤트 핸들러를 등록
            }

        }
        public void UserControlDays_OnPanelClick(object sender, EventArgs e)
        {
            UserControldays clickedPanel = sender as UserControldays;//클릭한 패널 가져오기
            string clickedDate = clickedPanel.DayLabelText; //클릭한 패널에서 날자 정보 추출


            DateTime clickedDateTime = new DateTime(year, month, int.Parse(clickedDate));// 클릭된 패널의 날짜를 메시지로 표시.
            clickedDatetime = clickedDateTime;
            List<List<string>> linez = Patient.Att();

            dataGridView6.Rows.Clear();
            dataGridView3.Rows.Clear();

            foreach (var patientData in linez)
            {
                string scheduleDate = patientData.Last();
                if (scheduleDate == clickedDateTime.ToString("yyyy-MM-dd"))
                {

                    dataGridView6.Rows.Add(patientData.ToArray()); // 클릭한 날짜와 스케줄 날짜가 일치하는 경우 DataGridView에 행 추가
                }
            }
            dataGridView2.Rows.Clear(); // 그리드뷰의 모든 행 제거
            // DataGridView2 설정
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView2.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;


            List<List<string>> lines = Patient.Line(); // 예약된 환자 정보 가져오기
            foreach (var patientData in lines)
            {
                try
                {

                    string reservationDate = patientData.Last(); // 예약 날짜를 가져옴
                    if (clickedDateTime.ToString("yyyy-MM-dd") == reservationDate)
                    {

                        dataGridView3.Rows.Add(patientData.ToArray()); // DataGridView에 행 추가
                    }

                }
                catch (Exception ex)
                {
                    Text = $"예약 날짜 비교 중 오류 발생: {ex.Message}";
                }

            }

        }
        public void SetDayLabel(string day)
        {

            label13.Text = $"{DateTime.Now.Year}년 {DateTime.Now.Month}월 {day}일";// UserControlDays로부터 전달된 날짜 값을 받아서 라벨에 설정
        }
        public void label_Click(object sender, MouseEventArgs e)
        {

            UserControldays clickedPanel = sender as UserControldays; //클릭한 패널 가져오기
            clickedpanel = clickedPanel;
            string clickedDate = clickedPanel.lbdays.Text; //클릭한 패널에서 날자 정보 추출
            DateTime clickedDateTime = new DateTime(year, month, int.Parse(clickedDate));// 클릭된 패널의 날짜를 메시지로 표시합니다.

            if (DateTime.Now.ToString("yyyy-MM-dd") == clickedDateTime.ToString("yyyy-MM-dd"))
            {


                List<List<string>> linez = Patient.Att();

                dataGridView6.Rows.Clear();
                dataGridView3.Rows.Clear();

                foreach (var patientData in linez)
                {
                    string scheduleDate = patientData.Last();
                    if (scheduleDate == clickedDateTime.ToString("yyyy-MM-dd"))// 클릭한 날짜와 스케줄 날짜가 일치하는 경우 DataGridView에 행 추가
                    {
                        dataGridView6.Rows.Add(patientData.ToArray());
                    }
                }
                

                // 예약된 환자 정보 가져오기
                List<List<string>> lines = Patient.Line();
                foreach (var patientData in lines)
                {
                    try
                    {

                        string reservationDate = patientData.Last(); // 예약 날짜를 가져옴
                        if (clickedDateTime.ToString("yyyy-MM-dd") == reservationDate)
                        {
                            // DataGridView에 행 추가
                            dataGridView3.Rows.Add(patientData.ToArray());
                        }

                    }
                    catch (Exception ex)
                    {
                        Text = $"예약 날짜 비교 중 오류 발생: {ex.Message}";
                    }

                }
            }


        }
        private void Form_main_Load(object sender, EventArgs e)
        {
            // main_textBox1.BorderColor = Color.Gray;

            // 재고------------------------------------------------------------------------------------------------------------------------------------
            this.button3_1_1.BackgroundImage = Properties.Resources.search1;
            this.button3_1_2.BackgroundImage = Properties.Resources.search1;
            this.button3_1_1.BackgroundImageLayout = ImageLayout.Stretch;
            this.button3_3_1.BackgroundImageLayout = ImageLayout.Stretch;
            this.button3_3_2.BackgroundImageLayout = ImageLayout.Stretch;
            this.button3_1_2.BackgroundImageLayout = ImageLayout.Stretch;
            // -------------------------------------------------------------------------------------------------------------------------------------재고


            //데이터그리드 첫 번째 줄 안 눌려있게
            dataGridView1.ClearSelection();

            dataGridView1.DefaultCellStyle.Font = new Font("G마켓 산스 TTF Light", 14); // 원하는 폰트 및 크기로 변경


            Font ft2 = new Font("G마켓 산스 TTF Light", 16, FontStyle.Underline);
            button1.Font = ft2;

            timer1.Interval = 100; // 타이머 간격 100ms
            timer1.Start();  // 타이머 시작  

            chart1.Series.Clear();
            chart1.Series.Add("이번주 방문객 수");


            List<List<string>> lines = Patient.Line();



            //오늘을 기준으로 이번주 월요일 가져오기
            DateTime today = DateTime.Today;

            DateTime mondayDate = today.AddDays(Convert.ToInt32(DayOfWeek.Monday) - Convert.ToInt32(today.DayOfWeek));
            //MessageBox.Show(mondayDate.ToString());
            //textBox1.Text = (mondayDate.ToString());

            //Grid 없애기
            chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = false;

            chart1.ChartAreas[1].AxisX.MajorGrid.Enabled = false;
            chart1.ChartAreas[1].AxisY.MajorGrid.Enabled = false;


            // y축 설정
            this.chart1.ChartAreas[0].AxisY.Minimum = 0;
            this.chart1.ChartAreas[0].AxisY.Maximum = 30;

            this.chart1.ChartAreas[1].AxisY.Minimum = 0;
            this.chart1.ChartAreas[1].AxisY.Maximum = 30;

            //차트 추가
            chart1.Series.Add("연령별");
            chart1.Series[1].ChartArea = "ChartArea2";



            //
            //차트 폰트
            //

            // 차트 제목 폰트 변경
            //chart1.Titles[0].Font = new Font("G마켓 산스 TTF Light", 16, FontStyle.Bold);

            // 축 레이블 폰트 변경
            chart1.ChartAreas[0].AxisX.LabelStyle.Font = new Font("G마켓 산스 TTF Light", 10);
            chart1.ChartAreas[0].AxisY.LabelStyle.Font = new Font("G마켓 산스 TTF Light", 10);

            // 범례 폰트 변경
            chart1.Legends[0].Font = new Font("G마켓 산스 TTF Light", 12);

            // 차트 영역의 폰트 변경
            chart1.ChartAreas[0].AxisX.TitleFont = new Font("G마켓 산스 TTF Light", 14);
            chart1.ChartAreas[0].AxisY.TitleFont = new Font("G마켓 산스 TTF Light", 14);




            //
            //차트 실시간 처리
            //


/*            // 타이머 설정
            timer = new Timer();
            timer.Interval = 1000;
            timer.Tick += Timer_Tick;
           // 

            timer.Start();

*/
/*            // 차트 초기화
            chart1.Series.Add("RealTimeData");
            chart1.Series["RealTimeData"].ChartType = SeriesChartType.Line;
            chart1.Series["RealTimeData"].Points.AddY(0); // 초기 값 설정


*/








            // x축 설정 ChartArea2
            chart1.ChartAreas[1].AxisX.Interval = 1; // 각 연령 간격
            chart1.ChartAreas[1].AxisX.IntervalType = DateTimeIntervalType.Auto; // 연령 간격 설정



/*            // 연령별 x축
            chart1.Series[1].Points.AddXY("~19", GetAgeGroupCount(lines, "1"));
            chart1.Series[1].Points.AddXY("~29", GetAgeGroupCount(lines, "10-20"));
            chart1.Series[1].Points.AddXY("~39", GetAgeGroupCount(lines, "21-30"));
            chart1.Series[1].Points.AddXY("~49", GetAgeGroupCount(lines, "31-40"));
            chart1.Series[1].Points.AddXY("~59", GetAgeGroupCount(lines, "50-60"));
            chart1.Series[1].Points.AddXY("60~", GetAgeGroupCount(lines, "61"));*/

            // outpatient.ClinicCountUpdated += UpdateClinicCount;


            string medicalFilePath = "medical.txt";
            string[] medical_lines = File.ReadAllLines(medicalFilePath);


            // 이번 주 월요일부터 금요일까지의 요일 설정
            DateTime thisMonday = GetThisWeekMonday();


            // 차트 초기화
            Form_login.form_main.chart1.Series[0].Points.Clear();

            chart1.ChartAreas[0].AxisX.Interval = 1; // 각 요일 간격
            chart1.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.Auto; // 요일 간격 설정

            // UpdateChartTimer_Tick();

            // medical_lines 전체 개수를 textBox1에 표시
            //Form_login.form_main.chart1.Series[0].Points.Clear();
            UpdateChart();

        }

/*        private void Timer_Tick(object sender, EventArgs e)
        {

            // 이번 주 월요일부터 금요일까지의 요일 설정
            DateTime thisMonday = GetThisWeekMonday();
            for (int i = 0; i < 5; i++)
            {
                DateTime currentDay = thisMonday.AddDays(i);

                int medicalLinesCount = 0;

                if (currentDay.Date == DateTime.Today.Date)
                {
                    // 오늘의 날짜인 경우에만 해당 날짜의 medical_lines 수를 가져옴
                    medicalLinesCount = GetMedicalLinesCountForDay(currentDay);
                }

                // 차트에 x축에 월요일부터 금요일까지 고정하면서 오늘의 날짜에 해당하는 요일에만 y값을 설정
                int v = chart1.Series[0].Points.AddXY(currentDay.ToString("ddd"), medicalLinesCount);
                // Form_login.form_main.textBox1.Text = medicalLinesCount.ToString();

            }

        }*/

        public void UpdateChart()
        {

            // 이번 주 월요일부터 금요일까지의 요일 설정
            DateTime thisMonday = GetThisWeekMonday();
            for (int i = 0; i < 5; i++)
            {
                DateTime currentDay = thisMonday.AddDays(i);

                int medicalLinesCount = 0;

                if (currentDay.Date == DateTime.Today.Date)
                {
                    // 오늘의 날짜인 경우에만 해당 날짜의 medical_lines 수를 가져옴
                    medicalLinesCount = GetMedicalLinesCountForDay(currentDay);
                }



                // 차트에 x축에 월요일부터 금요일까지 고정하면서 오늘의 날짜에 해당하는 요일에만 y값을 설정
                int v = chart1.Series[0].Points.AddXY(currentDay.ToString("ddd"), medicalLinesCount);
                

                // Form_login.form_main.textBox1.Text = medicalLinesCount.ToString();

            }

        }

        public void UpdateChartTimer_Tick()
        {
            // 타이머 간격에 따라 주기적으로 차트 업데이트
            UpdateChart();
        }

        // 해당 날짜의 medical_lines 수를 가져오는 함수 정의
        private int GetMedicalLinesCountForDay(DateTime day)
        {
            string filePath = "medical.txt"; // 실제 파일 경로로 변경

            string[] medical_lines = File.ReadAllLines(filePath);
            int v = medical_lines.Length;
            label35.Text = v.ToString();
            return v;
        }


        // 대기 인원 업데이트 메서드



/*        //연령별 인원 수 
        private int GetAgeGroupCount(List<List<string>> lines, string ageGroup)
        {

            string filePath = "medical.txt"; // 실제 파일 경로로 변경

            string[] medical_lines = File.ReadAllLines(filePath);
            string[] countss = medical_lines.ToString().Split('\t');
            //for
            int count = 0;
            //foreach (var line in lines)
            //{
            string patientAge = countss[3]; // Assuming the age information is in the 4th column (adjust as needed)
            if (patientAge == ageGroup)
            {
                count++; // Increment count for the specified age group
            }
            //}
            return count;
        }
*/


        // 현재 주의 월요일을 가져오는 메서드
        private DateTime GetThisWeekMonday()
        {
            DateTime today = DateTime.Today;
            int diff = today.DayOfWeek - DayOfWeek.Monday;
            return today.AddDays(-diff);
        }



        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel1_1.Visible = true;
            panel1_2.Visible = true;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel8.Visible = false;

            Font ft1 = new Font("G마켓 산스 TTF Light", 10);

            Font ft2 = new Font("G마켓 산스 TTF Light", 16, FontStyle.Underline);
            button1.Font = ft2;
            button2.Font = ft1;
            button3.Font = ft1;
            button4.Font = ft1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel1_1.Visible = false;
            panel1_2.Visible = false;
            panel2.Visible = true;
            panel3.Visible = false;
            panel4.Visible = false;
            panel8.Visible = false;
            Font ft1 = new Font("G마켓 산스 TTF Light", 10);

            Font ft2 = new Font("G마켓 산스 TTF Light", 16, FontStyle.Underline);
            button2.Font = ft2;
            button1.Font = ft1;
            button3.Font = ft1;
            button4.Font = ft1;



        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel1_1.Visible = false;
            panel1_2.Visible = false;
            panel2.Visible = false;
            panel3.Visible = true;
            panel4.Visible = false;
            panel8.Visible = false;
            Form_login.form_main.dataGridView3_2_1.Rows.Clear();
            //Inventory.Line_inv();
            textBox3_1_1.Focus();
            Font ft1 = new Font("G마켓 산스 TTF Light", 10);

            Font ft2 = new Font("G마켓 산스 TTF Light", 16, FontStyle.Underline);
            button3.Font = ft2;
            button2.Font = ft1;
            button1.Font = ft1;
            button4.Font = ft1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel1_1.Visible = false;
            panel1_2.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = true;
            panel8.Visible = false;
            Font ft1 = new Font("G마켓 산스 TTF Light", 10);

            Font ft2 = new Font("G마켓 산스 TTF Light", 16, FontStyle.Underline);
            button4.Font = ft2;
            button2.Font = ft1;
            button3.Font = ft1;
            button1.Font = ft1;
            //함수
            Manage.management();        // 간호사 이름과 직급
            Manage.M_payment();           // 결재올린 제품들
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToString("F"); // label1에 현재날짜시간 표시, F:자세한 전체 날짜/시간
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Patient.Psearch();
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel8.Visible = true;
        }





        // 재고----------------------------------------------------------------------------------------------------------------------------------------------------------
        private static bool IsNumeric(string input)
        {
            foreach (char c in input)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }
        private void textBox3_1_1_Click(object sender, EventArgs e)             // 코드 입력창
        {
            textBox3_1_1.Text = null;
        }
        private void textBox3_1_1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button3_1_1_Click(sender, e);
            }
        }
        
        private void textBox3_1_2_Click(object sender, EventArgs e)             // 이름 입력창
        {
            textBox3_1_2.Text = null;
        }
        private void textBox3_1_2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button3_1_2_Click(sender, e);
            }
        }
        private void textBox3_2_1_Click(object sender, EventArgs e)             // 수량 입력창
        {
            textBox3_2_1.Text = null;
        }
        private void textBox3_3_1_Click(object sender, EventArgs e)             // 장바구니 수량 입력창
        {
            textBox3_3_1.Text = null;
        }
        
        private void button3_1_1_Click(object sender, EventArgs e)          // 제품코드 검색 버튼
        {
            dataGridView3_2_1.Rows.Clear();
            Inventory.line_inv();
        }
        private void button3_1_2_Click(object sender, EventArgs e)          // 제품코드 검색 버튼
        {
            dataGridView3_2_1.Rows.Clear();
            Inventory.line_inv();
            textBox3_1_2.Focus();
            textBox3_2_1.Visible = false;
        }
        private void button3_1_3_Click(object sender, EventArgs e)        // 제품 등록 버튼
        {
            form_inv_add = new Form_inv_add();
            form_inv_add.ShowDialog();
        }
        private void button3_1_3_KeyDown(object sender, KeyEventArgs e)     // 작동 안됨
        {
            if (e.KeyCode == Keys.Tab)
            {
                textBox3_1_1.Focus();
            }
        }
        private void button3_2_1_Click(object sender, EventArgs e)        // 사용버튼
        {
            Inventory.use_inv();
            textBox3_2_1.Text = null;
            textBox3_2_1.Focus();
        }
        private void button3_2_2_Click(object sender, EventArgs e)        // 주문버튼
        {
            Inventory.order_inv();
            textBox3_2_1.Text = null;
            textBox3_2_1.Focus();
        }
        private void button3_2_2_KeyDown(object sender, KeyEventArgs e)     // 작동안됨
        {
            if(e.KeyCode == Keys.Tab)
            {
                textBox3_2_1.Focus();
            }
        }

        private async void button3_3_1_Click(object sender, EventArgs e)          // 장바구니 마이너스 버튼
        {
            if(textBox3_3_1.Text != "" && IsNumeric(textBox3_3_1.Text))
            {
                for (int i = 0; i < dataGridView3_3_1.Rows.Count; i++)
                {
                    if ((Convert.ToBoolean(dataGridView3_3_1.Rows[i].Cells[3].Value) == true))
                    {
                        int x = int.Parse((string)dataGridView3_3_1.Rows[i].Cells[1].Value);
                        if (x >= Int32.Parse(textBox3_3_1.Text))
                        {
                            dataGridView3_3_1.Rows[i].Cells[1].Value = (x - Int32.Parse(textBox3_3_1.Text)).ToString();
                        }
                        else
                        {
                            textBox3_3_1.Text = null;
                            label3_3_2.Text = "잘못된 값입니다.";
                            break;
                        }
                    }
                }
            }
            else
            {
                textBox3_3_1.Text = null;
                textBox3_3_1.Focus();
                label3_3_2.Text = "잘못된 값입니다.";
            }
            await Task.Delay(1000);                     // 일정시간후 에러메시지 삭제
            label3_3_2.Text = null;
        }

        private async void button3_3_2_Click(object sender, EventArgs e)          // 장바구니 플러스 버튼
        {
            if(textBox3_3_1.Text != "" && IsNumeric(textBox3_3_1.Text))
            {
                for (int i = 0; i < dataGridView3_3_1.Rows.Count; i++)
                {
                    if (Convert.ToBoolean(dataGridView3_3_1.Rows[i].Cells[3].Value) == true)
                    {
                        int x = int.Parse((string)dataGridView3_3_1.Rows[i].Cells[1].Value);
                        dataGridView3_3_1.Rows[i].Cells[1].Value = (x + Int32.Parse(textBox3_3_1.Text)).ToString();
                    }
                }
            }
            else
            {
                textBox3_3_1.Text = null;
                textBox3_3_1.Focus();
                label3_3_2.Text = "잘못된 값입니다.";
            }
            await Task.Delay(1000);                     // 일정시간후 에러메시지 삭제
            label3_3_2.Text = null;
        }
        private void button3_3_3_Click(object sender, EventArgs e)         // 결재버튼
        {
            Inventory.app_inv();
            // 관리자에서 결재 메뉴에서 텍스트파일 출력
        }
        

        private void dataGridView3_2_1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int count = 0;
            // 카테고리 행을 제외하고, 체크박스가 있는 열이고, 체크박스가 false일때
            if (e.RowIndex >= 0 && e.ColumnIndex == 3 && Convert.ToBoolean(dataGridView3_2_1.Rows[e.RowIndex].Cells[3].Value) == false)
            {
                dataGridView3_2_1.Rows[e.RowIndex].Cells[3].Value = true;       // 체크박스를 true
            }
            else if (e.RowIndex >= 0 && e.ColumnIndex == 3 && Convert.ToBoolean(dataGridView3_2_1.Rows[e.RowIndex].Cells[3].Value) == true)
            {
                dataGridView3_2_1.Rows[e.RowIndex].Cells[3].Value = false;
            }
            for (int i = 0; i < dataGridView3_2_1.Rows.Count; i++)
            {
                if (Convert.ToBoolean(dataGridView3_2_1.Rows[i].Cells[3].Value) == true)        // 선택되어있는 체크박스가 하나라도 있는 경우
                {
                    textBox3_2_1.Visible = true;
                    textBox3_2_1.Text = "1";          // 기본 1로
                    textBox3_2_1.Focus();
                    count++;
                }
                else if (count == 0)         // 선택되어있는 체크박스가 하나도 없는 경우
                {
                    textBox3_2_1.Visible = false;
                }
            }
            
        }
        private bool allselected1 = false;
        private void dataGridView3_2_1_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex == 3)
            {
                allselected1 = !allselected1;
                for (int i = 0; i < dataGridView3_2_1.RowCount; i++)
                {
                    dataGridView3_2_1.Rows[i].Cells[3].Value = allselected1;
                }
            }
        }
        private void dataGridView3_3_1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int count = 0;
            if (e.RowIndex >= 0 && e.ColumnIndex == 2 && Convert.ToBoolean(dataGridView3_3_1.Rows[e.RowIndex].Cells[2].Value) == false)      // 선택을 눌렀을때 삭제버튼이 false이기 때문에 삭제됨
            {
                dataGridView3_3_1.Rows.RemoveAt(e.RowIndex);
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == 3 && Convert.ToBoolean(dataGridView3_3_1.Rows[e.RowIndex].Cells[3].Value) == false)
            {
                dataGridView3_3_1.Rows[e.RowIndex].Cells[3].Value = true;       // 체크박스를 true
            }
            else if (e.RowIndex >= 0 && e.ColumnIndex == 3 && Convert.ToBoolean(dataGridView3_3_1.Rows[e.RowIndex].Cells[3].Value) == true)
            {
                dataGridView3_3_1.Rows[e.RowIndex].Cells[3].Value = false;
            }
            for (int i = 0; i < dataGridView3_3_1.Rows.Count; i++)
            {
                if (Convert.ToBoolean(dataGridView3_3_1.Rows[i].Cells[3].Value) == true)
                {
                    button3_3_1.Visible = true;
                    button3_3_2.Visible = true;
                    textBox3_3_1.Visible = true;
                    textBox3_3_1.Focus();
                    count++;
                }
                else if (count == 0)         // 선택되어있는 체크박스가 하나도 없는 경우
                {
                    button3_3_1.Visible = false;
                    button3_3_2.Visible = false;
                    textBox3_3_1.Visible = false;
                }
            }
        }
        private bool allselected2 = false;
        private void dataGridView3_3_1_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex == 3)
            {
                allselected2 = !allselected2;
                for (int i = 0; i < dataGridView3_3_1.RowCount; i++)
                {
                    dataGridView3_3_1.Rows[i].Cells[3].Value = allselected2;
                }
            }
        }

        // ----------------------------------------------------------------------------------------------------------------------------------------------------------재고




        private void main_textBox_Click(object sender, EventArgs e)
        {
            panel8.Visible = true;
        }

        private void button5_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {


            Patient.Psearch();

            if (panel1.Visible == true)
            {
                panel1.Visible = true;
                panel2.Visible = false;
                panel3.Visible = false;
                panel4.Visible = false;
            }
            else if (panel2.Visible == true)
            {
                panel1.Visible = false;
                panel2.Visible = true;
                panel3.Visible = false;
                panel4.Visible = false;
            }
            else if (panel3.Visible == true)
            {
                panel1.Visible = false;
                panel2.Visible = false;
                panel3.Visible = true;
                panel4.Visible = false;
            }
            else
            {
                panel1.Visible = false;
                panel2.Visible = false;
                panel3.Visible = false;
                panel4.Visible = true;
            }
            panel8.Visible = true;
            //dataGridView 처음에 셀 선택 안 되어있게
            dataGridView2.ClearSelection();



        }

        private void main_textBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Patient.Psearch();
            }
        }

        private void button8_Click_2(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                // 선택된 행의 데이터를 가져오기
                DataGridViewRow selectedRow = dataGridView2.SelectedRows[0];

                // 선택된 행의 데이터를 가져와서 문자열 배열로 변환
                string[] rowData = new string[selectedRow.Cells.Count];
                for (int i = 0; i < selectedRow.Cells.Count; i++)
                {
                    rowData[i] = selectedRow.Cells[i].Value.ToString();
                }
                // 폼2(outpatient)의 인스턴스 생성 및 데이터 전달
                outpatient formOutpatient = new outpatient(rowData);
                formOutpatient.Show();
            }
            else
            {
                MessageBox.Show("접수환자의 정보가 없습니다.");
            }
        }



       

        private void button6_Click_1(object sender, EventArgs e)
        {
            try
            {
                Patient.Pnew();
                textBox4.Text = null;
                textBox5.Text = null;
                textBox6.Text = null;
                textBox7.Text = null;
            }
            catch
            {
                label10.Visible = true;
            }

        }


        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            label3.Text = textBox4.Text;
            char[] inputchars = textBox4.Text.ToCharArray();          //한글만 들어가게
            var sb = new StringBuilder();

            foreach (var item in inputchars)
            {
                if (char.GetUnicodeCategory(item) == UnicodeCategory.OtherLetter)
                {
                    sb.Append(item);
                    label10.Visible = false;
                }
                else
                {
                    label10.Visible = true;
                }
            }
            textBox4.Text = sb.ToString().Trim();

        }


        private void EventHandler()
        {
            throw new NotImplementedException();
        }

        //주민번호 19991111이런식으로 입력하면 1999-11-11로 변환해서 저장되게 수정할것
        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            //숫자와 백스페이스와 '-'만 입력 형식에 맞지않게써도 뒤에 사용할 데이트타임변환에서 막혀서 메모장으로 안들어감
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back) || e.KeyChar == '-'))
            {
                e.Handled = true;
                label10.Visible = true;
            }
            else
            {
                label10.Visible = false;
            }
        }

        //한글입력시에도 경고문 뜨게 수정
        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back) || e.KeyChar == '-'))
            {
                e.Handled = true;
                label10.Visible = true;
            }
            else
            {
                label10.Visible = false;
            }
        }

        private void textBox4_Click(object sender, EventArgs e)
        {
            label10.Visible = false;

        }

        private void textBox5_Click(object sender, EventArgs e)
        {
            label10.Visible = false;
        }

        private void textBox6_Click(object sender, EventArgs e)
        {
            label10.Visible = false;
        }

        private void textBox7_Click(object sender, EventArgs e)
        {
            label10.Visible = false;
        }

      

        private void label3_Click(object sender, EventArgs e)
        {

            textBox4.Focus();

            textBox4.MaxLength = 7;
            label3.Text = null;
            textBox4.Text = null;
        }

        private void label4_Click(object sender, EventArgs e)
        {

            textBox5.Focus();
            textBox5.MaxLength = 10;
            label4.Text = null;
            textBox5.Text = null;

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            label4.Text = textBox5.Text;

        }

        private void label11_Click(object sender, EventArgs e)
        {
            textBox6.Focus();
            textBox6.MaxLength = 13;
            label11.Text = null;
            textBox6.Text = null;

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            label11.Text = textBox6.Text;

        }

        private void label12_Click(object sender, EventArgs e)
        {
            textBox7.Focus();
            textBox7.MaxLength = 13;
            label12.Text = null;
            textBox7.Text = null;

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            label12.Text = textBox7.Text;

        }

        private void textBox4_Enter(object sender, EventArgs e)
        {
            label3.Text = string.Empty;
        }

        private void textBox5_Enter(object sender, EventArgs e)
        {
            label4.Text = string.Empty;
        }

        private void textBox6_Enter(object sender, EventArgs e)
        {
            label11.Text = string.Empty;
        }

        private void textBox7_Enter(object sender, EventArgs e)
        {
            label12.Text = string.Empty;
        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button6_Click(sender, e);
            }

        }

        private void textBox5_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button6_Click(sender, e);
            }
        }

        private void textBox6_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button6_Click(sender, e);
            }
        }

        private void textBox7_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button6_Click(sender, e);
            }
        }

        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {



        }
    





        private void button13_Click(object sender, EventArgs e)  // 수납버튼 클릭시 
        {
            Payment();
        }

        public static void Payment()
        {
            if (Form_login.form_main.dataGridView2.SelectedRows.Count > 0)
            {
                // 선택된 행의 데이터를 가져오기
                DataGridViewRow selectedRow = Form_login.form_main.dataGridView2.SelectedRows[0];

                // 선택된 행의 데이터를 가져와서 문자열 배열로 변환
                string[] rowData = new string[selectedRow.Cells.Count];
                for (int i = 0; i < selectedRow.Cells.Count; i++)
                {
                    rowData[i] = selectedRow.Cells[i].Value.ToString();
                }
                // 폼2(outpatient)의 인스턴스 생성 및 데이터 전달
                Form_pay form_Pay = new Form_pay(rowData);
                form_Pay.Show();
            }
            else
            {
                string[] rrr = new string[50];
                Form_pay form_Pay = new Form_pay(rrr);
                form_Pay.Show();
            }


        }




/*        private void richTextBox1_Enter(object sender, EventArgs e)
        {
            this.main_textBox1.Focus();
        }

        private void richTextBox2_Enter(object sender, EventArgs e)
        {
            this.main_textBox1.Focus();
        }*/

        

       

       
        private void Daycontainer_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button17_Click_1(object sender, EventArgs e)
        {
            Daycontainer.Controls.Clear();
            month++;
            if (month > 12)
            {
                month = 1;
                year++;
            }
            DateTime startofthemonth = new DateTime(year, month, 1);// 다음달 첫날의 정보를 가져옴
            int days = DateTime.DaysInMonth(year, month); //다음달 일 수 계산
            int dayoftheweek = Convert.ToInt32(startofthemonth.DayOfWeek.ToString("d")); // 다음 달의 시작 요일을 계산
            for (int i = 0; i < dayoftheweek; i++)  // 다음 달의 시작 요일까지 공백 패널을 추가
            {
                UserControl ucblank = new UserControlBlank(); //공백 패널 생성
                Daycontainer.Controls.Add(ucblank); //공백 패널 추가
            }
            for (int i = 1; i <= days; i++)// 다음 달의 각 날짜에 해당하는 패널을 추가
            {
                UserControldays ucdays = new UserControldays(); //날짜 패널 생성
                ucdays.days(i); //패널에 날짜 설정
                Daycontainer.Controls.Add(ucdays); //날짜 패널 추가
            }
            label13.Text = $"{year}년 {month}월"; // 라벨에 다음 달의 연도와 월을 표시
            foreach (Control control in Daycontainer.Controls) // 패널에 있는 UserControlDays의 클릭 이벤트 핸들러를 등록
            {
                if (control is UserControldays)
                {
                    (control as UserControldays).OnPanelClick += UserControlDays_OnPanelClick; // 해당 패널의 클릭 이벤트 핸들러 등록
                }
            }
        }

        private void button18_Click_1(object sender, EventArgs e)
        {
            Daycontainer.Controls.Clear();
            month--;
            if (month < 1)
            {
                month = 12;
                year--;
            }
            DateTime startofthemonth = new DateTime(year, month, 1); //지난달 첫날의 정보를 가져옴
            int days = DateTime.DaysInMonth(year, month);//지난달 일 수 계산
            int dayoftheweek = Convert.ToInt32(startofthemonth.DayOfWeek.ToString("d"));// 지난 달의 시작 요일을 계산
            for (int i = 0; i < dayoftheweek; i++)// 지난 달의 시작 요일까지 공백 패널을 추가
            {
                UserControl ucblank = new UserControlBlank();//공백 패널 생성
                Daycontainer.Controls.Add(ucblank); //공백 패널 추가
            }
            for (int i = 1; i <= days; i++)// 지난 달의 각 날짜에 해당하는 패널을 추가
            {
                UserControldays ucdays = new UserControldays();//날짜 패널 생성
                ucdays.days(i);//날짜 패널 설정
                Daycontainer.Controls.Add(ucdays);//날짜 패널 추가
            }
            label13.Text = $"{year}년 {month}월";// 라벨에 지난 달의 연도와 월을 표시
            foreach (Control control in Daycontainer.Controls) // 패널에 있는 UserControlDays의 클릭 이벤트 핸들러를 등록
            {
                if (control is UserControldays)
                {
                    (control as UserControldays).OnPanelClick += UserControlDays_OnPanelClick; // 해당 패널의 클릭 이벤트 핸들러 등록
                }
            }
        }

        private void button7_Click(object sender, EventArgs e) //출근버튼
        {
            string check_schedule = "schedule.txt";
            DateTime selectedDate = clickedDatetime; // 달력 날짜


            DateTime today = DateTime.Now; // 오늘의 날짜를 가져옴

            if (selectedDate.ToString("yyyy-MM-dd") == today.ToString("yyyy-MM-dd")) // 선택한 날짜와 오늘 날짜를 비교
            {
                try
                {
                    List<string> lines = File.ReadAllLines(check_schedule).ToList();
                    for (int i = 0; i < lines.Count; i++)
                    {
                        string[] columns = lines[i].Split('\t');
                        if (columns[0] == this.name && columns[3] == "X" && columns[7] == today.ToString("yyyy-MM-dd"))
                        {
                            MessageBox.Show("출근 하셨습니다.");
                            columns[3] = "O";
                            columns[1] = today.ToString("HHmm");
                            lines[i] = string.Join("\t", columns); // 변경된 값을 다시 합쳐서 해당 줄로 설정
                            File.WriteAllLines(check_schedule, lines); // 변경된 내용을 파일에 씀
                            break;
                        }

                        if (columns[0] == this.name && columns[3] == "O" && columns[7] == today.ToString("yyyy-MM-dd"))
                        {
                            MessageBox.Show("출근을 취소 하셨습니다.");
                            columns[3] = "X";
                            columns[1] = "-";
                            lines[i] = string.Join("\t", columns); // 변경된 값을 다시 합쳐서 해당 줄로 설정
                            File.WriteAllLines(check_schedule, lines); // 변경된 내용을 파일에 씀
                            break;
                        }
                    }

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
            else
            {
                MessageBox.Show("오늘은 " + DateTime.Now.ToString("yyyy년-MM월-dd일") + " 이아닙니다");

            }
        }
        private void button19_Click(object sender, EventArgs e) //월차 버튼
        {
            Form_vacation formVacation = new Form_vacation(form_login, form_login.Name, form_login.UserBirth, form_login.UserRent);


            // 생성된 인스턴스를 보여줌
            formVacation.Show();
        }
        // 관리자 이벤트 -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private void button4_1_Click(object sender, EventArgs e)
        {
            // 새로운 폼만들기
            // 이름, 주민번호, 주소, 전화번호, 은행, 계좌번호, 입사일, 이메일, ID, PW, monthrent, 직급, 사진 입력
        }



        private void button4_3_Click(object sender, EventArgs e)
        {
            string file_a = "approval.txt";
            List<string> list = File.ReadAllLines(file_a).ToList();
            string file_d = "approval_done.txt";            // 결제완료된 제품을 넣을 파일
            List<string> header = new List<string>();       // 카테고리 행을 담을 리스트
            List<string> lines = new List<string>();        // 내용을 담을 리스트
            for(int i = 0;i < list.Count;i++) 
            {
                // List<string> rows = list[i].Split('\t').ToList();
                if(i == 0)
                {
                    header.Add(list[i]);
                }
                else
                {
                    for (int j = dataGridView4_4.RowCount - 1; j >= 0; j--)
                    {
                        if(Convert.ToBoolean(dataGridView4_4.Rows[j].Cells[3].Value))
                        {
                            string done = (dataGridView4_4.Rows[j].Cells[0].Value + "\t" + dataGridView4_4.Rows[j].Cells[1].Value + "\t" + DateTime.Now.ToString() + "\n");
                            File.AppendAllText(file_d, done);        // approval_done.txt 추가
                            dataGridView4_4.Rows.RemoveAt(j);       // 데이터그리드에서 삭제
                        }
                        else
                        {
                            //string approval = (dataGridView4_4.Rows[j].Cells[0].Value + "\t" + dataGridView4_4.Rows[j].Cells[1].Value + "\t" + dataGridView4_4.Rows[j].Cells[2].Value);
                            lines.Add(dataGridView4_4.Rows[j].Cells[0].Value + "\t" + dataGridView4_4.Rows[j].Cells[1].Value + "\t" + dataGridView4_4.Rows[j].Cells[2].Value);
                            dataGridView4_4.Rows.RemoveAt(j);
                        }
                    }
                }
            }
            File.WriteAllLines(file_a, header); 
            File.AppendAllLines(file_a, lines);
            List<string> second = File.ReadAllLines(file_a).ToList();
            if (file_a.Length > 1)
            {
                for (int i = 1; i < second.Count; i++)
                {
                    List<string> data = second[i].Split('\t').ToList();
                    dataGridView4_4.Rows.Add(data[0], data[1], data[2]);
                    // 기능은 제대로 구현되지만 인덱스 에러가 뜸
                    // 재고에서 삭제 버튼, 모두 선택
                }
            }
        }

        private void button11_Click(object sender, EventArgs e) //퇴근
        {
            string check_schedule = "schedule.txt";
            DateTime selectedDate = clickedDatetime; // 달력 날짜


            DateTime today = DateTime.Now; // 오늘의 날짜를 가져옴


            if (selectedDate.ToString("yyyy-MM-dd") == today.ToString("yyyy-MM-dd")) // 선택한 날짜와 오늘 날짜를 비교
            {

                try
                {
                    List<string> lines = File.ReadAllLines(check_schedule).ToList();
                    for (int i = 0; i < lines.Count; i++)
                    {
                        string[] columns = lines[i].Split('\t');
                        if (columns[0] == this.name && columns[4] == "X" && columns[7] == today.ToString("yyyy-MM-dd") && columns[3] == "O")
                        {
                            MessageBox.Show("퇴근 하셨습니다.");
                            columns[4] = "O";
                            columns[2] = today.ToString("HHmm");
                            int start = int.Parse(columns[1]);
                            int end = int.Parse(columns[2]);
                            int worktime = end - start;
                            columns[6] = worktime.ToString();
                            workcount++;
                            if (today.Day == 1)
                            {
                                columns[5] = "1";
                            }
                            else
                            {
                                columns[5] = workcount.ToString();
                            }
                            lines[i] = string.Join("\t", columns); // 변경된 값을 다시 합쳐서 해당 줄로 설정
                            File.WriteAllLines(check_schedule, lines); // 변경된 내용을 파일에 씀
                            break; // 이름이 일치하는 행을 찾았으므로 루프를 중지합니다.
                        }
                        if (columns[0] == this.name && columns[4] == "O" && columns[7] == today.ToString("yyyy-MM-dd"))
                        {
                            MessageBox.Show("퇴근을 취소 하셨습니다.");
                            columns[4] = "X";
                            columns[2] = "-";
                            workcount--;
                            if (workcount < 0)
                            {
                                workcount = 0;
                            }
                            columns[5] = workcount.ToString();
                            lines[i] = string.Join("\t", columns); // 변경된 값을 다시 합쳐서 해당 줄로 설정
                            File.WriteAllLines(check_schedule, lines); // 변경된 내용을 파일에 씀
                            break; // 이름이 일치하는 행을 찾았으므로 루프를 중지합니다.
                        }
                    }
                }
                catch(Exception Ex) 
                {
                    MessageBox.Show(Ex.Message);
                }
            }
            else
            {
                MessageBox.Show("오늘은 " + DateTime.Now.ToString("yyyy년-MM월-dd일") + " 이아닙니다");

            }
        }

        private void dataGridView6_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (button12.Text == "수정")
            {
                button12.Text = "완료";
                dataGridView2.EditMode = DataGridViewEditMode.EditOnEnter; // 편집 모드 설정
                dataGridView2.ReadOnly = false;
            }
            else
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel8_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }



        private void Form_main_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel1_2_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel1_1_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel1_3_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void tabControl1_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel5_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel12_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel14_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel13_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel3_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel3_1_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel3_3_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel3_2_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel4_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dataGridView4_1_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel4_1_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void tabControl2_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dataGridView4_2_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel6_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void chart1_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void tabPage1_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void tabPage2_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void label2_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void label1_MouseClick(object sender, MouseEventArgs e)
        {
            if (panel8.Visible && !panel8.Bounds.Contains(e.Location))
            {
                try
                {
                    // DataGridView의 각 행에서 빈칸 체크 및 예외 처리
                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue; // 새로운 행은 무시

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                            {
                                MessageBox.Show("빈칸을 채워주세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }
                    }
                    panel8.Visible = false;
                    button12.Text = "수정";
                    dataGridView2.ReadOnly = true;
                    Patient.SaveDataToTextFile();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private bool allselected3 = false;
        private void dataGridView4_4_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex == 3)
            {
                allselected3 = !allselected3;
                for (int i = 0; i < dataGridView4_4.RowCount; i++)
                {
                    dataGridView4_4.Rows[i].Cells[3].Value = allselected3;
                }
            }
        }

        private void panel13_Paint(object sender, PaintEventArgs e)
        {
            Color borderColor = Color.FromArgb(203, 223, 242);
            ControlPaint.DrawBorder(e.Graphics, this.panel13.ClientRectangle, borderColor, ButtonBorderStyle.Solid);
        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Color borderColor = Color.FromArgb(203, 216, 242);
            ControlPaint.DrawBorder(e.Graphics, this.panel1.ClientRectangle, borderColor, ButtonBorderStyle.Solid);
        }

        private void button1_1_Click(object sender, EventArgs e)
        {
            /* this.Close();
             form_login.ShowDialog();*/

            // form_main.ShowDialog();
    /*        this.Visible = false;
            form_login.Visible = true;*/
            form_login.textBox1.Text = null;
            form_login.textBox2.Text = null;


            this.Hide();
            form_login.ShowDialog();
            this.Close();
            form_login.textBox1.Focus();
            form_login.label3.Text = "ID를 입력해주세요.";
            form_login.label4.Text = "PW를 입력해주세요.";



        }

/*        private void button16_MouseHover(object sender, EventArgs e)
        {
            Font ft2 = new Font("G마켓 산스 TTF Light", 14, FontStyle.Underline);
            button16.Font = ft2;
        }*/

        private void button1_1_MouseLeave(object sender, EventArgs e)
        {
            Font ft2 = new Font("G마켓 산스 TTF Light", 14);
            button1_1.Font = ft2;
        }

        private void main_textBox_TextChanged(object sender, EventArgs e)
        {
            label34.Text = main_textBox.Text;
        }

        private void label34_Click(object sender, EventArgs e)
        {
            main_textBox.Focus();
        }

        private void button1_1_MouseMove(object sender, MouseEventArgs e)
        {
            Font ft2 = new Font("G마켓 산스 TTF Light", 14, FontStyle.Underline);
            button1_1.Font = ft2;
        }

        private void button6_MouseMove(object sender, MouseEventArgs e)
        {
            Font ft2 = new Font("G마켓 산스 TTF Light", 16, FontStyle.Underline);
            button6.Font = ft2;
        }

        private void button6_MouseLeave(object sender, EventArgs e)
        {
            Font ft2 = new Font("G마켓 산스 TTF Light", 16);
            button6.Font = ft2;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                Patient.Pnew();
                textBox4.Text = null;
                textBox5.Text = null;
                textBox6.Text = null;
                textBox7.Text = null;
            }
            catch
            {
                label10.Visible = true;
            }

        }

        private void button13_MouseMove(object sender, MouseEventArgs e)
        {
            Font ft2 = new Font("G마켓 산스 TTF Light", 16, FontStyle.Underline);
            button13.Font = ft2;

        }

        private void button13_MouseLeave(object sender, EventArgs e)
        {
            Font ft2 = new Font("G마켓 산스 TTF Light", 16);
            button13.Font = ft2;
        }






        //------------------------panel border ------------------------------------------------------------

        /* private void panel1_1_Paint(object sender, PaintEventArgs e)
         {
             ControlPaint.DrawBorder(e.Graphics, this.panel1_1.ClientRectangle, Color.MidnightBlue, ButtonBorderStyle.Solid);
         }

         private void panel1_2_Paint(object sender, PaintEventArgs e)
         {
             ControlPaint.DrawBorder(e.Graphics, this.panel1_2.ClientRectangle, Color.MidnightBlue, ButtonBorderStyle.Solid);
         }

         private void panel1_3_Paint(object sender, PaintEventArgs e)
         {
             ControlPaint.DrawBorder(e.Graphics, this.panel1_3.ClientRectangle, Color.MidnightBlue, ButtonBorderStyle.Solid);
         }

         private void panel12_Paint(object sender, PaintEventArgs e)
         {
             ControlPaint.DrawBorder(e.Graphics, this.panel12.ClientRectangle, Color.MidnightBlue, ButtonBorderStyle.Solid);
         }

         private void panel14_Paint(object sender, PaintEventArgs e)
         {
             ControlPaint.DrawBorder(e.Graphics, this.panel14.ClientRectangle, Color.MidnightBlue, ButtonBorderStyle.Solid);
         }

         private void panel13_Paint(object sender, PaintEventArgs e)
         {
             ControlPaint.DrawBorder(e.Graphics, this.panel13.ClientRectangle, Color.MidnightBlue, ButtonBorderStyle.Solid);
         }

         private void panel3_1_Paint(object sender, PaintEventArgs e)
         {
             ControlPaint.DrawBorder(e.Graphics, this.panel3_1.ClientRectangle, Color.MidnightBlue, ButtonBorderStyle.Solid);
         }

         private void panel3_3_Paint(object sender, PaintEventArgs e)
         {
             ControlPaint.DrawBorder(e.Graphics, this.panel3_3.ClientRectangle, Color.MidnightBlue, ButtonBorderStyle.Solid);
         }

         private void panel3_2_Paint(object sender, PaintEventArgs e)
         {
             ControlPaint.DrawBorder(e.Graphics, this.panel3_2.ClientRectangle, Color.MidnightBlue, ButtonBorderStyle.Solid);

         }

         private void panel9_Paint(object sender, PaintEventArgs e)
         {
             ControlPaint.DrawBorder(e.Graphics, this.panel9.ClientRectangle, Color.MidnightBlue, ButtonBorderStyle.Solid);
         }

         private void panel7_Paint(object sender, PaintEventArgs e)
         {
             ControlPaint.DrawBorder(e.Graphics, this.panel7.ClientRectangle, Color.MidnightBlue, ButtonBorderStyle.Solid);
         }

         private void panel10_Paint(object sender, PaintEventArgs e)
         {
             ControlPaint.DrawBorder(e.Graphics, this.panel10.ClientRectangle, Color.MidnightBlue, ButtonBorderStyle.Solid);
         }
 */




        //------------------------panel border ------------------------------------------------------------

        private void dataGridView4_1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Manage.p_info(e.RowIndex);
            Manage.p_salary(e.RowIndex);
        }


        // ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ 관리자 이벤트

    }

}

class Patient
{

    public static List<string> text_ss()
    {
        string P_path = "Reservation.txt";      // 환자 정보 텍스트 파일
        string[] lines = File.ReadAllLines(P_path);       // 파일의 모든 줄을 읽어옴
        List<string> linesList = lines.ToList();
        return linesList;
    }


    public static List<string> Att_cal()
    {
        string schedule = "schedule.txt";
        string[] sch = File.ReadAllLines(schedule);
        List<string> schcel = sch.ToList();
        return schcel;
    }
    public static List<List<string>> Att()
    {
        List<string> AttData = new List<string>();
        List<List<string>> Att_list = new List<List<string>>();
        List<string> linez = Patient.Att_cal();
        for (int i = 0; i < linez.Count; i++)          // 파일 내용을 한 줄씩 읽어가며 처리
        {
            AttData = linez[i].Split('\t').ToList();
            Att_list.Add(AttData); // 각 환자 데이터 리스트를 전체 리스트에 추가
        }
        return Att_list;
    }

    public static List<List<string>> Line()
    {
        List<List<string>> patient_list = new List<List<string>>(); // 각 줄의 데이터를 저장한 리스트를 저장할 리스트
        List<string> lines = Patient.text_ss();
        for (int i = 0; i < lines.Count; i++)          // 파일 내용을 한 줄씩 읽어가며 처리
        {
            List<string> patientData = lines[i].Split('\t').ToList();
            patient_list.Add(patientData); // 각 환자 데이터 리스트를 전체 리스트에 추가
        }
        return patient_list;
    }


    public static void Pnew()
    {
        string text_name = Form_login.form_main.textBox4.Text;
        string text_ssnum = Form_login.form_main.textBox5.Text;
        string text_phone = Form_login.form_main.textBox6.Text;
        string text_address = Form_login.form_main.textBox7.Text;

        // 하나라도 비어있으면 데이터를 파일에 추가하지 않음
        if (string.IsNullOrEmpty(text_name) || string.IsNullOrEmpty(text_ssnum) || string.IsNullOrEmpty(text_phone) || string.IsNullOrEmpty(text_address))
        {
            Form_login.form_main.label10.Visible = true;
            return;
        }

        // 전화번호 형식 변환
        if (text_phone.Length == 11) // 입력된 전화번호가 11자리인 경우에만 변환
        {
            string formatted_phone = $"{text_phone.Substring(0, 3)}-{text_phone.Substring(3, 4)}-{text_phone.Substring(7)}";
            text_phone = formatted_phone;
        }

        DateTime Pnew_age;

        // 6자리의 연도를 받아와서 yyyy-MM-dd 형태로 변경
        string yearString = text_ssnum.Substring(0, 2);
        int yearPrefix = int.Parse(yearString);
        int currentYear = DateTime.Now.Year % 100;
        string fullYearString = yearPrefix > currentYear ? "19" + yearString : "20" + yearString;

        // 나머지 날짜 정보를 가져와서 날짜로 변경
        string dateString = fullYearString + text_ssnum.Substring(2);
        if (!DateTime.TryParseExact(dateString, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out Pnew_age))
        {
            Form_login.form_main.label10.Visible = true;
            return;
        }
        string formatted_ssnum = Pnew_age.ToString("yyyy-MM-dd");

        DateTime today = DateTime.Now;

        int age = today.Year - Pnew_age.Year + 1;
        string text_age = age < 10 ? "0" + age.ToString() : age.ToString();

        string Pnew_info = $"{text_name}\t{text_age}\t{formatted_ssnum}\t{text_phone}\t{text_address}";

        string patient = "Patient.txt";

        if (File.ReadAllText(patient).Contains(Pnew_info))
        {
            MessageBox.Show("등록된 환자입니다.");
            return;
        }

        // 파일에 추가
        File.AppendAllText(patient, Pnew_info + Environment.NewLine);

    }



    public static void Psearch()
    {
        try
        {
            string PatientFilePath = "Patient.txt"; // 환자 정보 파일 경로
            string P_search = Form_login.form_main.main_textBox.Text; // 환자 검색창에서 입력된 이름
            string[] lines = File.ReadAllLines(PatientFilePath); // 파일의 모든 줄 읽기

            // 데이터그리드뷰 초기화
            Form_login.form_main.dataGridView2.Rows.Clear();

            for (int i = 1; i < lines.Length; i++)
            {
                if (string.IsNullOrWhiteSpace(P_search) || lines[i].Contains(P_search))
                {
                    string[] columns = lines[i].Split('\t'); // 탭으로 구분된 열을 분리

                    DataGridViewRow row = new DataGridViewRow();
                    for (int j = 0; j < columns.Length; j++)
                    {
                        DataGridViewTextBoxCell cell = new DataGridViewTextBoxCell();
                        cell.Value = columns[j];
                        row.Cells.Add(cell);
                    }
                    Form_login.form_main.dataGridView2.Rows.Add(row);
                }
            }
        }
        catch
        {

        }
    }
    public static void SelectedData(string selectedData)
    {
        if (Form_login.form_main.dataGridView2.SelectedRows.Count > 0) //선택된 데이터그리드뷰의 길이(개수)가 0보다 클때만 작동
        {
            DataGridViewRow selectedRow = Form_login.form_main.dataGridView2.SelectedRows[0]; //선택한 셀의 인덱스
            string[] rowData = new string[selectedRow.Cells.Count];//셀의 길이(단어갯수?)를 배열에 담음---셀의 길이 만큼 포문돌리기위해(개별로찢으려고)
            for (int i = 0; i < selectedRow.Cells.Count; i++)
            {
                rowData[i] = selectedRow.Cells[i].Value.ToString();//포문을 돌려 셀을 개별로 찢은후 순서대로 rowData 배열에 배치
            }
            outpatient formOutpatient = new outpatient(rowData);//outpatient 의 인스턴스 생성---인스턴스생성해서 서로 다른 폼간에 정보교환가능
            Form_pay form_Pay = new Form_pay(rowData);
            formOutpatient.Show();
        }
        else
        {

        }

    }
    public static void SaveDataToTextFile()
    {
        using (StreamWriter writer = new StreamWriter("Patient.txt"))
        {
            writer.WriteLine("이름" + "\t" + "나이" + "\t" + "주민번호" + "\t" + "전화번호" + "\t" + "주소");

            foreach (DataGridViewRow row in Form_login.form_main.dataGridView2.Rows)
            {
                // DataGridView의 각 행에서 셀 값을 가져와서 텍스트 파일에 쓰기
                string line = string.Join("\t", row.Cells.Cast<DataGridViewCell>().Select(cell => cell.Value.ToString()));
                writer.WriteLine(line);
            }
        }
    }

    




}




class Manage
{
    public static void management()             //직원 메모장 불러오기
    {
        /*  string path = "Info.txt";
          // Info 파일 경로
          List<string> lines = File.ReadAllLines(path).ToList();
          return lines;*/
        try
        {
            string ManageFilePath = "Info.txt"; // 환자 정보 파일 경로
            string[] lines = File.ReadAllLines(ManageFilePath); // 파일의 모든 줄 읽기

            // 데이터그리드뷰 초기화
            Form_login.form_main.dataGridView4_1.Rows.Clear();

            for (int i = 0; i < lines.Length; i++)
            {
                string[] columns = lines[i].Split('\t'); // 탭으로 구분된 열을 분리
                if (i > 0 && columns[10] != "O")
                {
                    Form_login.form_main.dataGridView4_1.Rows.Add(columns[0], columns[12]);
                }
            }
            Form_login.form_main.dataGridView4_1.CurrentCell = null;
        }
        catch
        {

        }
    }
    public static void p_info(int RowIndex)             // 개인정보 함수
    {
        //Form_login form_Login = new Form_login(); 
        string path = "Info.txt";  // Info 파일 경로
        // AppDomain.CurrentDomain.BaseDirectory = 현재 실행중인 프로그램의 기본 디렉토리
        // C:/Users/301-08/Desktop/Project_4/Project_4/bin/Debug/
        DirectoryInfo debugFolder = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
        FileInfo[] files = debugFolder.GetFiles();      // AppDomain.CurrentDomain.BaseDirectory안에 있는 파일들을 불러오기
        int name = 0, birth = 0, address = 0, phone = 0, start = 0, email = 0, picture = 0; // 열번호를 저장할 변수
        try
        {
            List<string> lines = File.ReadAllLines(path).ToList();       // 파일의 모든 줄을 읽고 리스트화
            for (int i = 0; i < lines.Count; i++)          // 파일 내용을 한 줄씩 읽어가며 처리, lines.count는 info.txt의 행길이
            {
                List<string> rows = lines[i].Split('\t').ToList();    // lines[i]를 탭으로 나눠서 리스트에 배치, {"이름","주민번호",...}

                // textBox2.Text = Form_login.form_main.dataGridView4.SelectedRows[0].Cells[0].Value.ToString();
                //MessageBox.Show(rows[0].ToString());
                if (i == 0)                     // 카테고리 행
                {
                    name = rows.IndexOf("이름");
                    birth = rows.IndexOf("주민번호");
                    address = rows.IndexOf("주소");
                    phone = rows.IndexOf("전화번호");
                    start = rows.IndexOf("입사일");
                    email = rows.IndexOf("이메일");
                    picture = rows.IndexOf("사진");
                }
                else
                {
                    if (Form_login.form_main.dataGridView4_1.Rows[RowIndex].Cells[0].Value.ToString() == rows[0])       // datagridview의 이름열의 값과 info.txt의 이름열값과 같다면
                    {
                        Form_login.form_main.textBox4_1_1.Text = rows[name].ToString();
                        Form_login.form_main.textBox4_1_2.Text = rows[birth].ToString();
                        Form_login.form_main.textBox4_1_3.Text = rows[address].ToString();
                        Form_login.form_main.textBox4_1_4.Text = rows[phone].ToString();
                        Form_login.form_main.textBox4_1_5.Text = rows[start].ToString();
                        Form_login.form_main.textBox4_1_6.Text = rows[email].ToString();
                        for (int j = 0; j < files.Length; j++)          // debug폴더내에서 이미지 찾기
                        {
                            string file = files[j].ToString();      // file = 파일명.확장자
                            if (rows[picture] == file)
                            {
                                string debugFolderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, rows[picture]);    // 이미지 경로
                                Image backgroundImage = Image.FromFile(debugFolderPath);        // 이미지 불러오기
                                Form_login.form_main.panel4_1_1.BackgroundImage = backgroundImage;
                                Form_login.form_main.panel4_1_1.BackgroundImageLayout = ImageLayout.Stretch;
                                break;
                            }
                        }
                    }
                }
            }
        }
        catch { }
    }
    public static void p_salary(int RowIndex)               // 월급내역, 2년전까지 확인가능
    {
        Form_login.form_main.dataGridView4_2.Rows.Clear();
        string path = "Info.txt";  // Info 파일 경로
        List<string> lines = File.ReadAllLines(path).ToList();
        int bank = 0, account = 0, holder = 0;
        for (int i = 0; i < lines.Count; i++)          // info내용만큼 반복
        {
            List<string> rows = lines[i].Split('\t').ToList();
            if (i == 0)
            {
                bank = rows.IndexOf("은행");
                account = rows.IndexOf("계좌번호");
                holder = rows.IndexOf("이름");        // 이름이자 예금주
            }
            else
            {
                if (rows[holder] == Form_login.form_main.dataGridView4_1.Rows[RowIndex].Cells[0].Value.ToString())         // 파일의 예금주와 데이터그리드의 이름과 같다면
                {
                    Form_login.form_main.dataGridView4_2.Rows.Add(DateTime.Now.ToString("yyyy-MM"), "", "", rows[bank], rows[account], rows[holder], "N");
                }
            }
        }
    }
    public static void M_payment()            // 결재 탭
    {
        Form_login.form_main.dataGridView4_4.Rows.Clear();
        string path = "approval.txt";
        List<string> lines = File.ReadAllLines(path).ToList();
        int name = 0, count = 0, time = 0;
        for (int i = 0; i < lines.Count; i++)
        {
            int temp = 0;
            List<string> rows = lines[i].Split('\t').ToList();
            if (i == 0)
            {
                name = rows.IndexOf("제품명");
                count = rows.IndexOf("수량");
                time = rows.IndexOf("결재시간");
            }
            else
            {
                if (Form_login.form_main.dataGridView4_4.RowCount == 0)     // 데이터그리드에 아무것도 없으면
                {
                    Form_login.form_main.dataGridView4_4.Rows.Add(rows[name], Int32.Parse(rows[count]), rows[time]);
                }
                else
                {
                    for (int j = 0; j < Form_login.form_main.dataGridView4_4.RowCount; j++)     // 결재탭에 있는 제품수 만큼 반복
                    {
                        // 데이터그리드의 이름과 결재시간과 approval파일의 이름과 결재시간이 같으면 
                        if (rows[name] == Form_login.form_main.dataGridView4_4.Rows[j].Cells[0].Value.ToString() && rows[time] == Form_login.form_main.dataGridView4_4.Rows[j].Cells[2].Value.ToString())       // 이름과 결재시간이 같다면
                        {
                            int x = Int32.Parse(rows[count]);
                            Form_login.form_main.dataGridView4_4.Rows[j].Cells[1].Value = x + Int32.Parse(Form_login.form_main.dataGridView4_4.Rows[j].Cells[1].Value.ToString());      // 수량만 플러스
                            temp++;
                        }
                    }
                    if (temp == 0)
                    {
                        Form_login.form_main.dataGridView4_4.Rows.Add(rows[name], Int32.Parse(rows[count]), rows[time]);
                    }
                }
            }
        }
    }
}


/* public static void man_emp()  //직원 불러오기
 {
     List<string> lines = Manage.management();

     for (int i = 1; i < lines.Count; i++)          // 파일 내용을 한 줄씩 읽어가며 처리
     {
         for(int j=0; j < lines.Count; j++)
         {
             List<string> man_label = lines[i].Split('\t').ToList();

             string a = man_label;
             MessageBox.Show(a);
         }

     }

 }*/







class Inventory
{
    private static bool IsNumeric(string input)     // 숫자인지 확인
    {
        foreach (char c in input)
        {
            if (!char.IsDigit(c))
            {
                return false;
            }
        }
        return true;
    }
    public static List<string> text_inv()               // 제품
    {
        string I_path = "Inventory Manager.txt";      // 재품 정보 텍스트 파일
        List<string> lines = File.ReadAllLines(I_path).ToList();       // 파일의 모든 줄을 읽고 리스트화
        return lines;
    }
    public async static void line_inv()         // 제품 검색
    {
        string Code = Form_login.form_main.textBox3_1_1.Text;
        string Name = Form_login.form_main.textBox3_1_2.Text;
        List<string> inventory_data = new List<string>(); // 각 줄의 데이터를 저장할 리스트 생성
        List<List<string>> inventory_list = new List<List<string>>(); // 각 줄의 데이터를 저장한 리스트를 저장할 리스트
        List<string> lines = Inventory.text_inv();
        for (int i = 1; i < lines.Count; i++)          // 파일 내용을 한 줄씩 읽어가며 처리
        {
            inventory_data = lines[i].Split('\t').ToList();      // Inventory Manager의 각 줄
            if (Code != "" && Name != "")           // 둘다 입력되어 있을때
            {
                if (inventory_data[0].Length >= Code.Length && inventory_data[0].Substring(0, Code.Length) == Code && inventory_data[1].Length >= Name.Length && inventory_data[1].Substring(0, Name.Length) == Name)
                {
                    Form_login.form_main.dataGridView3_2_1.Rows.Add(inventory_data[0], inventory_data[1], Int32.Parse(inventory_data[2]));
                }
            }
            else if (Code != "" && Name == "")       // 코드에만 입력되어 있을때
            {
                if (inventory_data[0].Length >= Code.Length && inventory_data[0].Substring(0, Code.Length) == Code)
                {
                    Form_login.form_main.dataGridView3_2_1.Rows.Add(inventory_data[0], inventory_data[1], Int32.Parse(inventory_data[2]));
                }
            }
            else if (Code == "" && Name != "")      // 이름에만 입력되어 있을때
            {
                if (inventory_data[1].Length >= Name.Length && inventory_data[1].Substring(0, Name.Length) == Name)
                {
                    Form_login.form_main.dataGridView3_2_1.Rows.Add(inventory_data[0], inventory_data[1], Int32.Parse(inventory_data[2]));
                }
            }
            else
            {
                Form_login.form_main.dataGridView3_2_1.Rows.Add(inventory_data[0], inventory_data[1], Int32.Parse(inventory_data[2]));
            }
        }
        if (Form_login.form_main.dataGridView3_2_1.RowCount == 0)        // 일치하는 제품이 없을때
        {
            Form_login.form_main.label3_1_2.Text = "잘못된 값입니다.";
            await Task.Delay(1000);                     // 일정시간후 에러메시지 삭제
            Form_login.form_main.label3_1_2.Text = null;
        }
    }


    public static async void use_inv()         // 사용버튼
    {
        DataGridView Data1 = Form_login.form_main.dataGridView3_2_1;                // 제품 데이터그리드
        System.Windows.Forms.TextBox Count = Form_login.form_main.textBox3_2_1;     // 수량입력창
        Label Error = Form_login.form_main.label3_2_1;                              // 에러메시지
        List<string> inventory_data = new List<string>();                           // 각 줄의 데이터를 저장할 리스트 생성
        List<string> lines = Inventory.text_inv();
        if (Count.Text != "")
        {
            int x = 0;
            int y = 0;
            for (int i = 0; i < Data1.Rows.Count; i++)     // 체크박스가 선택되어있는 모든 행
            {
                if (IsNumeric(Count.Text) && (Convert.ToBoolean(Data1.Rows[i].Cells[3].Value) == true))         // 수량입력창에 숫자가 오고 체크박스에 선택이 되어있으면
                {
                    x = Int32.Parse(Count.Text);                                        // x = 수량 입력
                    y = Int32.Parse(Data1.Rows[i].Cells[2].Value.ToString());           // y = 재고 수량
                    if (y >= x)         // 재고가 입력수량보다 크거나 같을경우
                    {
                        Data1.Rows[i].Cells[2].Value = y - x;       // 재고 - 입력한 값
                    }
                    else                // 입력 수량이 재고보다 큰경우
                    {
                        Error.Text = "잘못된 값입니다.";
                        Count.Focus();
                    }
                }
                else if (!IsNumeric(Count.Text))       // 숫자가 입력되지 않은경우
                {
                    Error.Text = "잘못된 값입니다.";
                    Count.Focus();
                }
            }

            if (Error.Text != "잘못된 값입니다.")
            {
                // Inventory Manager파일에 변화 적용
                int code = 0, name = 0, value = 0;
                for (int i = 0; i < lines.Count; i++)          // 파일 내용을 한 줄씩 읽어가며 처리
                {
                    inventory_data = lines[i].Split('\t').ToList();            // Inventory Manager텍스트 파일의 각 줄을 탭으로 구분
                    if (i == 0)                                                // 카테고리 행 일때
                    {
                        code = inventory_data.IndexOf("제품코드");                 // 코드의 열번호
                        name = inventory_data.IndexOf("제품명");               // 제품명의 열번호
                        value = inventory_data.IndexOf("재고");                // 재고의 열번호
                    }
                    else
                    {
                        if (Data1.Rows[Data1.CurrentRow.Index].Cells[0].Value.ToString() == inventory_data[code])    // 선택한 행의 제품코드와 Inventory Manager의 제품코드와 같다면
                        {
                            int result = Int32.Parse(inventory_data[value]);        // 현재 텍스트파일에 있는 재고값
                            result -= x;                                            // 재고값 - 사용값
                            lines[i] = lines[i].Replace(inventory_data[value], result.ToString()); // 재고 열 값 변경
                        }
                    }
                }
            }
            // 파일에 변경된 값을 적용
            File.WriteAllLines("Inventory Manager.txt", lines);
        }
        else        // 수량입력창이 null일경우
        {
            Error.Text = "잘못된 값입니다.";
        }
        await Task.Delay(1000);                     // 일정시간후 에러메시지 삭제
        Error.Text = null; ;
    }
    public static async void order_inv()            // 주문버튼
    {
        System.Windows.Forms.TextBox Count = Form_login.form_main.textBox3_2_1;         // 수량입력창
        DataGridView Data1 = Form_login.form_main.dataGridView3_2_1;                    // 제품 데이터그리드
        DataGridView Data2 = Form_login.form_main.dataGridView3_3_1;                    // 장바구니
        Label Error = Form_login.form_main.label3_2_1;                                  // 에러메시지
        if (Count.Text != "")
        {
            for (int i = 0; i < Data1.Rows.Count; i++)         // 데이터그리드뷰3_2_1내의 제품수만큼 반복
            {
                if (IsNumeric(Count.Text) && Int32.Parse(Count.Text) > 0 && (Convert.ToBoolean(Data1.Rows[i].Cells[3].Value) == true))        // 수량입력창에 숫자가 입력되고, 0보다 크고, 체크박스에 선택이 되어있다면
                {
                    if (Data2.Rows.Count == 0)         // 장바구니에 아무것도 없으면
                    {
                        Data2.Rows.Add(Data1.Rows[i].Cells[1].Value, Count.Text);
                    }
                    else        // 장바구니에 제품이 있으면
                    {
                        int count = 0;     // 중복횟수
                        for (int j = 0; j < Data2.Rows.Count; j++)   // 장바구니의 제품만큼 반복
                        {
                            // 데이터그리드뷰1에 선택된 제품명과 장바구니에 있는 제품명이 같다면
                            if (Data1.Rows[i].Cells[1].Value.ToString() == Data2.Rows[j].Cells[0].Value.ToString())
                            {
                                int x = int.Parse((string)(Data2.Rows[j].Cells[1].Value));     // 장바구니에 추가한 수량
                                Data2.Rows[j].Cells[1].Value = (x + Int32.Parse(Count.Text)).ToString();
                                count++;
                            }
                        }
                        if (count == 0)     // 장바구니에 제품이 있고 중복이 아닐때
                        {
                            Data2.Rows.Add(Data1.Rows[i].Cells[1].Value, Count.Text);
                        }
                    }
                }
                else if (!IsNumeric(Count.Text) || Int32.Parse(Count.Text) == 0)       // 수량입력창에 숫자가 아니고 숫자인데 0일때
                {
                    Error.Text = "잘못된 값입니다.";
                }
            }
        }
        else       // 수량입력창이 null일 경우
        {
            Error.Text = "잘못된 값입니다.";
        }
        await Task.Delay(1000);                         // 일정시간후 에러메시지 삭제
        Error.Text = null;
    }

    public async static void app_inv()            // 결재버튼
    {
        DataGridView Data2 = Form_login.form_main.dataGridView3_3_1;
        Label Error = Form_login.form_main.label3_3_2;
        string A_path = "approval.txt";
        List<string> lines = new List<string>();        // 제품
        List<string> push = new List<string>();         // 파일에 넣을 리스트
        if (Data2.Rows.Count != 0)
        {
            for (int i = 0; i < Data2.RowCount; i++)             // 장바구니에 있는 제품수 만큼 반복
            {
                if (Int32.Parse(Data2.Rows[i].Cells[1].Value.ToString()) != 0)
                {
                    lines.Add(Data2.Rows[i].Cells[0].Value.ToString() + "\t" + Data2.Rows[i].Cells[1].Value.ToString() + "\t" + DateTime.Now.ToString("yyyy/MM/dd H:mm"));
                    File.AppendAllLines(A_path, lines);
                    lines.Clear();
                }
                else
                {
                    Error.Text = "수량이 0인 제품이 있습니다.";
                }
            }
            Data2.Rows.Clear();
            await Task.Delay(1000);                         // 일정시간후 에러메시지 삭제
            Error.Text = null;
        }
    }
}